// ============================================================================
// Comments Routes (/api/comments)
// ============================================================================

const { queryOne, execute } = require('../../database/db');
const { requireAuth } = require('../middleware/auth');
const { success, error } = require('../utils/helpers');

module.exports = function commentRoutes(router) {
  /**
   * DELETE /api/comments/:id
   * Delete a comment (Author only)
   */
  router.delete('/:id', requireAuth, (req, res) => {
    try {
      const commentId = parseInt(req.params.id, 10);
      if (isNaN(commentId)) {
        return error(res, 'Invalid comment ID.', 400);
      }

      const comment = queryOne('SELECT * FROM comments WHERE id = ?', [commentId]);
      if (!comment) {
        return error(res, 'Comment not found.', 404);
      }

      // Check author ownership
      if (comment.user_id !== req.user.id) {
        return error(res, 'Permission denied. You can only delete your own comments.', 403);
      }

      execute('DELETE FROM comments WHERE id = ?', [commentId]);
      return success(res, { message: 'Comment deleted successfully.' });
    } catch (err) {
      console.error('Delete comment error:', err);
      return error(res, 'Failed to delete comment.', 500);
    }
  });

  return router;
};
