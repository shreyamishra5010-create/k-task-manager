// ============================================================================
// Interactive Kanban Board Client Application
// HTML5 Drag & Drop, Filtering, Modals, Real-time DOM Updates
// ============================================================================

auth.requireAuth();

// Application State
let currentBoard = null;
let currentColumns = [];
let allTasks = [];
let currentMembers = [];
let currentUser = auth.getUser();
let draggedTaskId = null;
let dragPlaceholder = null;

// Search & Filter State
const filters = {
  q: '',
  priority: '',
  assignee: ''
};

document.addEventListener('DOMContentLoaded', () => {
  auth.renderNavbar();
  initBoard();
  setupFilterListeners();
  setupModalKeybindings();
});

/**
 * Initialize board by loading ID from URL
 */
async function initBoard() {
  const params = new URLSearchParams(window.location.search);
  const boardId = params.get('id');

  if (!boardId) {
    showToast('No board ID specified in URL.', 'error');
    setTimeout(() => window.location.href = '/dashboard.html', 1500);
    return;
  }

  await loadBoardData(boardId);
}

/**
 * Fetch full board data from backend
 */
async function loadBoardData(boardId) {
  try {
    const data = await api.get(`/api/boards/${boardId}`);
    currentBoard = data.board;
    currentColumns = data.columns || [];
    allTasks = data.tasks || [];
    currentMembers = data.members || [];

    renderBoardHeader();
    renderMembersAvatarStack();
    applyFiltersAndRender();
  } catch (err) {
    console.error('Failed to load board:', err);
    showToast(err.message, 'error');
    document.getElementById('board-canvas').innerHTML = `
      <div style="margin: 3rem auto; text-align: center; color: var(--danger);">
        <h2>Unable to load board</h2>
        <p style="margin: 0.5rem 0 1rem; color: var(--text-secondary);">${err.message}</p>
        <a href="/dashboard.html" class="btn btn-primary">Return to Dashboard</a>
      </div>
    `;
  }
}

/**
 * Render board sub-navbar
 */
function renderBoardHeader() {
  const titleDisplay = document.getElementById('board-title-display');
  const boardDesc = document.getElementById('board-desc-display');
  const roleBadge = document.getElementById('board-role-badge');
  const ownerActions = document.getElementById('board-owner-actions');

  if (titleDisplay) titleDisplay.textContent = currentBoard.name;
  if (boardDesc) boardDesc.textContent = currentBoard.description || '';
  
  if (roleBadge) {
    const isOwner = currentBoard.role === 'owner';
    roleBadge.className = `badge ${isOwner ? 'badge-owner' : 'badge-member'}`;
    roleBadge.textContent = isOwner ? 'Owner' : 'Member';
  }

  // Populate owner-only buttons
  if (ownerActions) {
    if (currentBoard.role === 'owner') {
      ownerActions.innerHTML = `
        <button class="btn btn-secondary btn-sm" onclick="openMembersModal()" title="Manage board members">
          <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
          <span>Members (${currentMembers.length})</span>
        </button>
        <button class="btn btn-secondary btn-sm" onclick="openRenameBoardModal()" title="Rename board">
          <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
        </button>
        <button class="btn btn-danger btn-sm" onclick="confirmDeleteBoard()" title="Delete board">
          <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
        </button>
      `;
    } else {
      ownerActions.innerHTML = `
        <button class="btn btn-secondary btn-sm" onclick="openMembersModal()" title="View board members">
          <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
          <span>Members (${currentMembers.length})</span>
        </button>
      `;
    }
  }

  // Populate assignee filter dropdown
  const assigneeSelect = document.getElementById('filter-assignee');
  if (assigneeSelect) {
    let optionsHtml = `
      <option value="">All Assignees</option>
      <option value="me">Assigned to Me</option>
      <option value="unassigned">Unassigned</option>
      <optgroup label="Board Members">
    `;
    currentMembers.forEach(m => {
      optionsHtml += `<option value="${m.id}">${escapeHtml(m.name)}</option>`;
    });
    optionsHtml += `</optgroup>`;
    assigneeSelect.innerHTML = optionsHtml;
  }
}

/**
 * Render member avatars stack in header
 */
function renderMembersAvatarStack() {
  const container = document.getElementById('board-members-stack');
  if (!container) return;

  container.innerHTML = currentMembers.slice(0, 5).map(m => `
    <div class="avatar-circle sm" style="background-color: ${m.avatar_color || '#4f46e5'}" title="${escapeHtml(m.name)} (${m.role})">
      ${auth.getInitials(m.name)}
    </div>
  `).join('');

  if (currentMembers.length > 5) {
    container.innerHTML += `
      <div class="avatar-circle sm" style="background: var(--text-muted);" title="${currentMembers.length - 5} more members">
        +${currentMembers.length - 5}
      </div>
    `;
  }
}

/**
 * Filter tasks and render columns + cards
 */
function applyFiltersAndRender() {
  let filtered = [...allTasks];

  // 1. Text Search Filter (title or description)
  if (filters.q) {
    const q = filters.q.toLowerCase();
    filtered = filtered.filter(t => 
      t.title.toLowerCase().includes(q) || 
      (t.description && t.description.toLowerCase().includes(q))
    );
  }

  // 2. Priority Filter
  if (filters.priority) {
    filtered = filtered.filter(t => t.priority === filters.priority);
  }

  // 3. Assignee Filter
  if (filters.assignee) {
    if (filters.assignee === 'me') {
      filtered = filtered.filter(t => t.assignee_id === currentUser.id);
    } else if (filters.assignee === 'unassigned') {
      filtered = filtered.filter(t => !t.assignee_id);
    } else {
      const targetId = parseInt(filters.assignee, 10);
      filtered = filtered.filter(t => t.assignee_id === targetId);
    }
  }

  renderBoardCanvas(filtered);
}

/**
 * Render all columns and tasks to the board canvas
 */
function renderBoardCanvas(tasksToRender) {
  const canvas = document.getElementById('board-canvas');
  if (!canvas) return;

  const isOwner = currentBoard.role === 'owner';
  const columnsHtml = currentColumns.map((col, colIdx) => {
    // Tasks belonging to this column, ordered by position
    const colTasks = tasksToRender
      .filter(t => t.column_id === col.id)
      .sort((a, b) => a.position - b.position);

    // Left/Right column reorder button states
    const canMoveLeft = colIdx > 0;
    const canMoveRight = colIdx < currentColumns.length - 1;

    return `
      <div class="column" data-column-id="${col.id}">
        <div class="column-header">
          <div class="column-title-wrapper">
            <span class="column-title" onclick="openRenameColumnModal(${col.id}, '${escapeHtml(col.name)}')" title="Click to rename column">
              ${escapeHtml(col.name)}
            </span>
            <span class="column-count">${colTasks.length}</span>
          </div>
          <div class="column-actions">
            ${canMoveLeft ? `
              <button class="btn-icon" onclick="moveColumn(${col.id}, ${col.position - 1})" title="Move column left">
                <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>
              </button>
            ` : ''}
            ${canMoveRight ? `
              <button class="btn-icon" onclick="moveColumn(${col.id}, ${col.position + 1})" title="Move column right">
                <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
              </button>
            ` : ''}
            ${isOwner ? `
              <button class="btn-icon" onclick="confirmDeleteColumn(${col.id}, '${escapeHtml(col.name)}')" title="Delete column">
                <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
              </button>
            ` : ''}
          </div>
        </div>

        <div class="column-tasks-list" data-column-id="${col.id}">
          ${colTasks.map(task => renderTaskCard(task)).join('')}
        </div>

        <div class="column-footer">
          <button class="btn-add-card" onclick="openCreateTaskModal(${col.id})">
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
            <span>Add a task</span>
          </button>
        </div>
      </div>
    `;
  }).join('');

  // Add "Add Column" card at the end of board
  const addColumnCard = `
    <div class="add-column-card">
      <button class="btn btn-secondary" onclick="openAddColumnModal()" style="width:100%;">
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
        <span>Add another column</span>
      </button>
    </div>
  `;

  canvas.innerHTML = columnsHtml + addColumnCard;

  // Attach Drag & Drop event listeners
  setupDragAndDrop();
}

/**
 * Render single task card HTML
 */
function renderTaskCard(task) {
  const priorityClass = `priority-${task.priority}`;
  const overdueBadge = task.is_overdue
    ? `<span class="overdue-pill" title="This task is past its due date!"><svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg> Overdue</span>`
    : '';

  const dueDateFormatted = task.due_date ? formatDate(task.due_date) : '';
  const assigneeAvatar = task.assignee_id
    ? `
      <div class="avatar-circle sm" style="background-color: ${task.assignee_avatar || '#4f46e5'}" title="Assigned to: ${escapeHtml(task.assignee_name)}">
        ${auth.getInitials(task.assignee_name)}
      </div>
    `
    : '';

  return `
    <div class="task-card ${task.is_overdue ? 'overdue-card' : ''}" 
         draggable="true" 
         data-task-id="${task.id}" 
         data-column-id="${task.column_id}"
         data-position="${task.position}">
      
      <div class="task-card-header">
        <div style="display:flex; align-items:center; gap:0.4rem; flex-wrap:wrap;">
          <span class="priority-pill ${priorityClass}">${task.priority}</span>
          ${overdueBadge}
        </div>
        <button class="btn-icon" onclick="event.stopPropagation(); toggleCardMenu(event, ${task.id})" title="Move task (Accessibility menu)">
          <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"></path></svg>
        </button>
      </div>

      <div class="task-card-title" onclick="openTaskModal(${task.id})">${escapeHtml(task.title)}</div>

      <div class="task-card-footer" onclick="openTaskModal(${task.id})">
        <div class="task-card-meta">
          ${task.due_date ? `
            <div class="meta-item" style="color: ${task.is_overdue ? 'var(--danger)' : 'inherit'}; font-weight: ${task.is_overdue ? '600' : 'normal'};">
              <svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
              <span>${dueDateFormatted}</span>
            </div>
          ` : ''}

          ${task.comment_count > 0 ? `
            <div class="meta-item">
              <svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path></svg>
              <span>${task.comment_count}</span>
            </div>
          ` : ''}
        </div>

        ${assigneeAvatar}
      </div>

      <!-- Accessible Move Dropdown Menu -->
      <div class="dropdown-menu" id="task-menu-${task.id}">
        <div style="padding: 0.4rem 0.75rem; font-size: 0.75rem; font-weight: 700; color: var(--text-muted); border-bottom: 1px solid var(--border-color);">
          MOVE TO COLUMN
        </div>
        ${currentColumns.map(c => `
          <button class="dropdown-item" onclick="moveTaskViaDropdown(${task.id}, ${c.id}, 0)">
            <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
            <span>${escapeHtml(c.name)} ${c.id === task.column_id ? '(Current)' : ''}</span>
          </button>
        `).join('')}
      </div>
    </div>
  `;
}

/**
 * Setup HTML5 Drag and Drop Handlers
 */
function setupDragAndDrop() {
  const cards = document.querySelectorAll('.task-card');
  const dropzones = document.querySelectorAll('.column-tasks-list');

  cards.forEach(card => {
    card.addEventListener('dragstart', (e) => {
      draggedTaskId = parseInt(card.getAttribute('data-task-id'), 10);
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', String(draggedTaskId));

      // Visual dragging styles
      requestAnimationFrame(() => card.classList.add('is-dragging'));
    });

    card.addEventListener('dragend', () => {
      card.classList.remove('is-dragging');
      document.querySelectorAll('.column').forEach(c => c.classList.remove('drag-over'));
      if (dragPlaceholder && dragPlaceholder.parentNode) {
        dragPlaceholder.remove();
      }
      dragPlaceholder = null;
      draggedTaskId = null;
    });
  });

  dropzones.forEach(zone => {
    zone.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      zone.closest('.column').classList.add('drag-over');

      // Create insertion indicator line
      if (!dragPlaceholder) {
        dragPlaceholder = document.createElement('div');
        dragPlaceholder.className = 'drag-indicator';
        dragPlaceholder.style.height = '3px';
        dragPlaceholder.style.background = 'var(--primary)';
        dragPlaceholder.style.borderRadius = '2px';
        dragPlaceholder.style.margin = '4px 0';
      }

      const afterElement = getDragAfterElement(zone, e.clientY);
      if (afterElement == null) {
        zone.appendChild(dragPlaceholder);
      } else {
        zone.insertBefore(dragPlaceholder, afterElement);
      }
    });

    zone.addEventListener('dragleave', (e) => {
      if (!zone.contains(e.relatedTarget)) {
        zone.closest('.column').classList.remove('drag-over');
      }
    });

    zone.addEventListener('drop', async (e) => {
      e.preventDefault();
      zone.closest('.column').classList.remove('drag-over');

      const taskId = parseInt(e.dataTransfer.getData('text/plain'), 10) || draggedTaskId;
      if (!taskId) return;

      const targetColId = parseInt(zone.getAttribute('data-column-id'), 10);

      // Determine new target position index
      const cardsInZone = [...zone.querySelectorAll('.task-card:not(.is-dragging)')];
      let newPosition = 0;
      if (dragPlaceholder && dragPlaceholder.parentNode === zone) {
        newPosition = cardsInZone.indexOf(dragPlaceholder.nextElementSibling);
        if (newPosition === -1) {
          newPosition = cardsInZone.length;
        }
      }

      if (dragPlaceholder && dragPlaceholder.parentNode) {
        dragPlaceholder.remove();
      }
      dragPlaceholder = null;

      await executeTaskMove(taskId, targetColId, newPosition);
    });
  });
}

/**
 * Calculate card element immediately after mouse cursor Y coordinate
 */
function getDragAfterElement(container, y) {
  const draggableElements = [...container.querySelectorAll('.task-card:not(.is-dragging)')];

  return draggableElements.reduce((closest, child) => {
    const box = child.getBoundingClientRect();
    const offset = y - box.top - box.height / 2;
    if (offset < 0 && offset > closest.offset) {
      return { offset: offset, element: child };
    } else {
      return closest;
    }
  }, { offset: Number.NEGATIVE_INFINITY }).element;
}

/**
 * Send PATCH /api/tasks/:id/move to backend
 */
async function executeTaskMove(taskId, columnId, position) {
  // Find current task in local memory
  const taskIndex = allTasks.findIndex(t => t.id === taskId);
  if (taskIndex === -1) return;

  const originalTask = { ...allTasks[taskIndex] };

  // Optimistic UI update
  allTasks[taskIndex].column_id = columnId;
  allTasks[taskIndex].position = position;

  // Re-render immediately for responsive feel
  applyFiltersAndRender();

  try {
    const response = await api.patch(`/api/tasks/${taskId}/move`, {
      column_id: columnId,
      position: position
    });
    // Sync with backend response
    if (response.task) {
      allTasks[taskIndex] = {
        ...allTasks[taskIndex],
        ...response.task
      };
    }
    // Reload full board state in background to ensure all column indexes are synchronized
    await loadBoardData(currentBoard.id);
  } catch (err) {
    // Revert optimistic update
    allTasks[taskIndex] = originalTask;
    applyFiltersAndRender();
    showToast(`Move failed: ${err.message}`, 'error');
  }
}

/**
 * Move task using accessible dropdown
 */
async function moveTaskViaDropdown(taskId, targetColumnId, position) {
  closeAllDropdowns();
  await executeTaskMove(taskId, targetColumnId, position);
}

function toggleCardMenu(event, taskId) {
  event.stopPropagation();
  const menu = document.getElementById(`task-menu-${taskId}`);
  const isShown = menu && menu.classList.contains('active');
  closeAllDropdowns();
  if (menu && !isShown) {
    menu.classList.add('active');
  }
}

function closeAllDropdowns() {
  document.querySelectorAll('.dropdown-menu').forEach(m => m.classList.remove('active'));
}

document.addEventListener('click', closeAllDropdowns);

/**
 * Reorder column left/right
 */
async function moveColumn(columnId, newPosition) {
  try {
    await api.put(`/api/columns/${columnId}`, { position: newPosition });
    await loadBoardData(currentBoard.id);
  } catch (err) {
    showToast(`Failed to move column: ${err.message}`, 'error');
  }
}

/**
 * Search and Filter Listeners
 */
function setupFilterListeners() {
  const searchInput = document.getElementById('search-tasks-input');
  const prioritySelect = document.getElementById('filter-priority');
  const assigneeSelect = document.getElementById('filter-assignee');
  const resetBtn = document.getElementById('reset-filters-btn');

  if (searchInput) {
    let debounceTimer;
    searchInput.addEventListener('input', (e) => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        filters.q = e.target.value.trim();
        applyFiltersAndRender();
      }, 200);
    });
  }

  if (prioritySelect) {
    prioritySelect.addEventListener('change', (e) => {
      filters.priority = e.target.value;
      applyFiltersAndRender();
    });
  }

  if (assigneeSelect) {
    assigneeSelect.addEventListener('change', (e) => {
      filters.assignee = e.target.value;
      applyFiltersAndRender();
    });
  }

  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      filters.q = '';
      filters.priority = '';
      filters.assignee = '';
      if (searchInput) searchInput.value = '';
      if (prioritySelect) prioritySelect.value = '';
      if (assigneeSelect) assigneeSelect.value = '';
      applyFiltersAndRender();
    });
  }
}

// ============================================================================
// Modals Management: Task Details, Comments, Members, Columns
// ============================================================================

let currentModalTaskId = null;

/**
 * Open Task Details & Comments Modal
 */
async function openTaskModal(taskId) {
  currentModalTaskId = taskId;
  const modal = document.getElementById('task-detail-modal');
  if (!modal) return;

  modal.classList.add('active');

  try {
    const data = await api.get(`/api/tasks/${taskId}`);
    const { task, comments, activities } = data;

    // Fill form fields
    document.getElementById('task-modal-title').value = task.title;
    document.getElementById('task-modal-desc').value = task.description || '';
    document.getElementById('task-modal-priority').value = task.priority;
    document.getElementById('task-modal-due').value = task.due_date || '';

    // Populate columns select in modal
    const colSelect = document.getElementById('task-modal-column');
    if (colSelect) {
      colSelect.innerHTML = currentColumns.map(c => `
        <option value="${c.id}" ${c.id === task.column_id ? 'selected' : ''}>
          ${escapeHtml(c.name)}
        </option>
      `).join('');
    }

    // Populate assignee select in modal
    const assigneeSelect = document.getElementById('task-modal-assignee');
    if (assigneeSelect) {
      assigneeSelect.innerHTML = `
        <option value="">Unassigned</option>
        ${currentMembers.map(m => `
          <option value="${m.id}" ${m.id === task.assignee_id ? 'selected' : ''}>
            ${escapeHtml(m.name)} (${escapeHtml(m.email)})
          </option>
        `).join('')}
      `;
    }

    // Render Comments
    renderTaskComments(comments || []);

    // Render Activity Log
    renderTaskActivities(activities || []);

  } catch (err) {
    showToast(`Failed to load task details: ${err.message}`, 'error');
    closeTaskModal();
  }
}

function closeTaskModal() {
  const modal = document.getElementById('task-detail-modal');
  if (modal) modal.classList.remove('active');
  currentModalTaskId = null;
}

/**
 * Save Task Details Changes
 */
async function saveTaskDetails(e) {
  e.preventDefault();
  if (!currentModalTaskId) return;

  const title = document.getElementById('task-modal-title').value.trim();
  const description = document.getElementById('task-modal-desc').value.trim();
  const priority = document.getElementById('task-modal-priority').value;
  const due_date = document.getElementById('task-modal-due').value || null;
  const assignee_id = document.getElementById('task-modal-assignee').value || null;
  const newColumnId = parseInt(document.getElementById('task-modal-column').value, 10);

  if (!title) {
    showToast('Task title is required.', 'error');
    return;
  }

  try {
    // 1. Update task metadata
    await api.put(`/api/tasks/${currentModalTaskId}`, {
      title,
      description,
      priority,
      due_date,
      assignee_id
    });

    // 2. Check if column changed
    const currentTask = allTasks.find(t => t.id === currentModalTaskId);
    if (currentTask && newColumnId && newColumnId !== currentTask.column_id) {
      await api.patch(`/api/tasks/${currentModalTaskId}/move`, {
        column_id: newColumnId,
        position: 0
      });
    }

    showToast('Task updated successfully!', 'success');
    closeTaskModal();
    await loadBoardData(currentBoard.id);
  } catch (err) {
    showToast(`Failed to save task: ${err.message}`, 'error');
  }
}

/**
 * Delete Task with Confirmation
 */
async function confirmDeleteTask() {
  if (!currentModalTaskId) return;

  if (!confirm('Are you sure you want to permanently delete this task?')) {
    return;
  }

  try {
    await api.delete(`/api/tasks/${currentModalTaskId}`);
    showToast('Task deleted successfully.', 'success');
    closeTaskModal();
    await loadBoardData(currentBoard.id);
  } catch (err) {
    showToast(`Failed to delete task: ${err.message}`, 'error');
  }
}

/**
 * Comments in Modal
 */
function renderTaskComments(comments) {
  const container = document.getElementById('task-modal-comments-list');
  if (!container) return;

  if (comments.length === 0) {
    container.innerHTML = `<p style="font-size:0.85rem; color:var(--text-muted); font-style:italic;">No comments yet. Start the conversation!</p>`;
    return;
  }

  container.innerHTML = comments.map(comm => {
    const isAuthor = comm.user_id === currentUser.id;
    return `
      <div class="comment-item">
        <div class="avatar-circle sm" style="background-color: ${comm.author_avatar || '#4f46e5'}">
          ${auth.getInitials(comm.author_name)}
        </div>
        <div class="comment-bubble">
          <div class="comment-meta">
            <span style="font-weight:600; color:var(--text-primary);">${escapeHtml(comm.author_name)}</span>
            <div style="display:flex; align-items:center; gap:0.5rem;">
              <span>${formatTimestamp(comm.created_at)}</span>
              ${isAuthor ? `
                <button class="btn-icon" onclick="deleteComment(${comm.id})" title="Delete your comment" style="padding:0;">
                  <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                </button>
              ` : ''}
            </div>
          </div>
          <div class="comment-content">${escapeHtml(comm.content)}</div>
        </div>
      </div>
    `;
  }).join('');
}

async function addComment(e) {
  e.preventDefault();
  if (!currentModalTaskId) return;

  const input = document.getElementById('new-comment-input');
  const content = input.value.trim();
  if (!content) return;

  try {
    await api.post(`/api/tasks/${currentModalTaskId}/comments`, { content });
    input.value = '';
    // Refresh modal
    openTaskModal(currentModalTaskId);
    // Refresh task in board view for updated comment count
    loadBoardData(currentBoard.id);
  } catch (err) {
    showToast(`Failed to post comment: ${err.message}`, 'error');
  }
}

async function deleteComment(commentId) {
  if (!confirm('Delete this comment?')) return;
  try {
    await api.delete(`/api/comments/${commentId}`);
    showToast('Comment deleted', 'success');
    openTaskModal(currentModalTaskId);
    loadBoardData(currentBoard.id);
  } catch (err) {
    showToast(err.message, 'error');
  }
}

/**
 * Activity Audit Trail
 */
function renderTaskActivities(activities) {
  const container = document.getElementById('task-modal-activity-list');
  if (!container) return;

  if (activities.length === 0) {
    container.innerHTML = `<li style="font-size:0.85rem; color:var(--text-muted);">No activity recorded.</li>`;
    return;
  }

  container.innerHTML = activities.map(act => `
    <li class="activity-item">
      <div class="avatar-circle" style="width:20px; height:20px; font-size:0.65rem; background-color:${act.user_avatar || '#4f46e5'}">
        ${auth.getInitials(act.user_name)}
      </div>
      <div>
        <strong>${escapeHtml(act.user_name)}</strong> ${escapeHtml(act.action)} 
        <span style="font-size:0.75rem; color:var(--text-muted); margin-left:0.25rem;">(${formatTimestamp(act.created_at)})</span>
      </div>
    </li>
  `).join('');
}

/**
 * Create New Task Modal
 */
let targetCreateColumnId = null;

function openCreateTaskModal(columnId) {
  targetCreateColumnId = columnId;
  const modal = document.getElementById('create-task-modal');
  if (!modal) return;

  // Populate assignee dropdown
  const select = document.getElementById('new-task-assignee');
  if (select) {
    select.innerHTML = `
      <option value="">Unassigned</option>
      ${currentMembers.map(m => `
        <option value="${m.id}">${escapeHtml(m.name)}</option>
      `).join('')}
    `;
  }

  modal.classList.add('active');
  setTimeout(() => document.getElementById('new-task-title')?.focus(), 100);
}

function closeCreateTaskModal() {
  const modal = document.getElementById('create-task-modal');
  if (modal) {
    modal.classList.remove('active');
    document.getElementById('create-task-form')?.reset();
  }
  targetCreateColumnId = null;
}

async function handleCreateTask(e) {
  e.preventDefault();
  if (!targetCreateColumnId) return;

  const title = document.getElementById('new-task-title').value.trim();
  const description = document.getElementById('new-task-desc').value.trim();
  const priority = document.getElementById('new-task-priority').value;
  const due_date = document.getElementById('new-task-due').value || null;
  const assignee_id = document.getElementById('new-task-assignee').value || null;

  if (!title) {
    showToast('Task title is required.', 'error');
    return;
  }

  try {
    await api.post(`/api/columns/${targetCreateColumnId}/tasks`, {
      title,
      description,
      priority,
      due_date,
      assignee_id
    });

    showToast('Task created successfully!', 'success');
    closeCreateTaskModal();
    await loadBoardData(currentBoard.id);
  } catch (err) {
    showToast(`Failed to create task: ${err.message}`, 'error');
  }
}

/**
 * Add / Rename Column Modals
 */
function openAddColumnModal() {
  const modal = document.getElementById('add-column-modal');
  if (modal) {
    modal.classList.add('active');
    setTimeout(() => document.getElementById('new-column-name')?.focus(), 100);
  }
}

function closeAddColumnModal() {
  const modal = document.getElementById('add-column-modal');
  if (modal) {
    modal.classList.remove('active');
    document.getElementById('add-column-form')?.reset();
  }
}

async function handleAddColumn(e) {
  e.preventDefault();
  const name = document.getElementById('new-column-name').value.trim();
  if (!name) return;

  try {
    await api.post(`/api/boards/${currentBoard.id}/columns`, { name });
    showToast('Column added!', 'success');
    closeAddColumnModal();
    await loadBoardData(currentBoard.id);
  } catch (err) {
    showToast(`Failed to add column: ${err.message}`, 'error');
  }
}

let targetRenameColId = null;

function openRenameColumnModal(colId, currentName) {
  targetRenameColId = colId;
  const modal = document.getElementById('rename-column-modal');
  if (modal) {
    const input = document.getElementById('rename-column-name');
    if (input) input.value = currentName;
    modal.classList.add('active');
    setTimeout(() => input?.focus(), 100);
  }
}

function closeRenameColumnModal() {
  const modal = document.getElementById('rename-column-modal');
  if (modal) modal.classList.remove('active');
  targetRenameColId = null;
}

async function handleRenameColumn(e) {
  e.preventDefault();
  if (!targetRenameColId) return;

  const name = document.getElementById('rename-column-name').value.trim();
  if (!name) return;

  try {
    await api.put(`/api/columns/${targetRenameColId}`, { name });
    showToast('Column renamed!', 'success');
    closeRenameColumnModal();
    await loadBoardData(currentBoard.id);
  } catch (err) {
    showToast(`Failed to rename column: ${err.message}`, 'error');
  }
}

async function confirmDeleteColumn(columnId, columnName) {
  if (!confirm(`Are you sure you want to delete column "${columnName}"? All tasks inside will be permanently deleted.`)) {
    return;
  }

  try {
    await api.delete(`/api/columns/${columnId}`);
    showToast('Column deleted.', 'success');
    await loadBoardData(currentBoard.id);
  } catch (err) {
    showToast(`Failed to delete column: ${err.message}`, 'error');
  }
}

/**
 * Rename Board
 */
function openRenameBoardModal() {
  const modal = document.getElementById('rename-board-modal');
  if (modal) {
    document.getElementById('rename-board-name').value = currentBoard.name;
    document.getElementById('rename-board-desc').value = currentBoard.description || '';
    modal.classList.add('active');
  }
}

function closeRenameBoardModal() {
  const modal = document.getElementById('rename-board-modal');
  if (modal) modal.classList.remove('active');
}

async function handleRenameBoard(e) {
  e.preventDefault();
  const name = document.getElementById('rename-board-name').value.trim();
  const description = document.getElementById('rename-board-desc').value.trim();

  if (!name) return;

  try {
    await api.put(`/api/boards/${currentBoard.id}`, { name, description });
    showToast('Board updated successfully!', 'success');
    closeRenameBoardModal();
    await loadBoardData(currentBoard.id);
  } catch (err) {
    showToast(`Failed to update board: ${err.message}`, 'error');
  }
}

/**
 * Delete Entire Board
 */
async function confirmDeleteBoard() {
  if (!confirm(`CAUTION: Are you sure you want to delete board "${currentBoard.name}"? This action cannot be undone.`)) {
    return;
  }

  try {
    await api.delete(`/api/boards/${currentBoard.id}`);
    showToast('Board deleted successfully.', 'success');
    setTimeout(() => window.location.href = '/dashboard.html', 800);
  } catch (err) {
    showToast(`Failed to delete board: ${err.message}`, 'error');
  }
}

/**
 * Members Management Modal
 */
function openMembersModal() {
  const modal = document.getElementById('members-modal');
  if (!modal) return;

  modal.classList.add('active');
  renderMembersList();
}

function closeMembersModal() {
  const modal = document.getElementById('members-modal');
  if (modal) {
    modal.classList.remove('active');
    document.getElementById('add-member-form')?.reset();
  }
}

function renderMembersList() {
  const list = document.getElementById('members-modal-list');
  if (!list) return;

  const isOwner = currentBoard.role === 'owner';

  list.innerHTML = currentMembers.map(m => `
    <div style="display:flex; align-items:center; justify-content:space-between; padding:0.6rem 0; border-bottom:1px solid var(--border-color);">
      <div style="display:flex; align-items:center; gap:0.75rem;">
        <div class="avatar-circle" style="background-color: ${m.avatar_color || '#4f46e5'}">
          ${auth.getInitials(m.name)}
        </div>
        <div>
          <div style="font-weight:600; font-size:0.9rem;">${escapeHtml(m.name)}</div>
          <div style="font-size:0.78rem; color:var(--text-secondary);">${escapeHtml(m.email)}</div>
        </div>
      </div>
      <div style="display:flex; align-items:center; gap:0.5rem;">
        <span class="badge ${m.role === 'owner' ? 'badge-owner' : 'badge-member'}">${m.role}</span>
        ${isOwner && m.role !== 'owner' ? `
          <button class="btn btn-danger btn-sm" onclick="removeMember(${m.id}, '${escapeHtml(m.name)}')">
            Remove
          </button>
        ` : ''}
      </div>
    </div>
  `).join('');
}

async function handleAddMember(e) {
  e.preventDefault();
  const emailInput = document.getElementById('add-member-email');
  const email = emailInput.value.trim();

  if (!email) return;

  try {
    await api.post(`/api/boards/${currentBoard.id}/members`, { email });
    showToast(`Member added successfully!`, 'success');
    emailInput.value = '';
    await loadBoardData(currentBoard.id);
    renderMembersList();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function removeMember(userId, name) {
  if (!confirm(`Remove ${name} from this board?`)) return;

  try {
    await api.delete(`/api/boards/${currentBoard.id}/members/${userId}`);
    showToast('Member removed', 'success');
    await loadBoardData(currentBoard.id);
    renderMembersList();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

/**
 * Close modals on ESC key
 */
function setupModalKeybindings() {
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeTaskModal();
      closeCreateTaskModal();
      closeAddColumnModal();
      closeRenameColumnModal();
      closeRenameBoardModal();
      closeMembersModal();
      closeAllDropdowns();
    }
  });

  // Modal backdrop click close
  document.querySelectorAll('.modal-backdrop').forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.remove('active');
      }
    });
  });
}

/**
 * Format Helpers
 */
function escapeHtml(str) {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr + 'T00:00:00');
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

function formatTimestamp(timestampStr) {
  if (!timestampStr) return '';
  const date = new Date(timestampStr.replace(' ', 'T') + 'Z');
  const now = new Date();
  const diffSec = Math.floor((now - date) / 1000);

  if (diffSec < 60) return 'Just now';
  if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
  if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h ago`;
  return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}
