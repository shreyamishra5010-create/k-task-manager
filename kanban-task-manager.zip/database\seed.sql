-- ============================================================================
-- Kanban Task Manager - Initial Seed Data
-- ============================================================================

PRAGMA foreign_keys = ON;

-- Clean existing data
DELETE FROM activity_log;
DELETE FROM comments;
DELETE FROM tasks;
DELETE FROM columns;
DELETE FROM board_members;
DELETE FROM boards;
DELETE FROM users;

-- 1. Users (Default password for all demo accounts is: password123)
-- Hash generated via scrypt / bcrypt compatible
INSERT INTO users (id, name, email, password_hash, avatar_color) VALUES 
(1, 'Alex Rivers', 'alex@example.com', 'scrypt$f0d111ac076cc378a2c7e40387f750ab$adf2344f24d6e145173818e9d6723e1ce4f2ca3478faaa1300bc26692ce3197fbf3c59c8640888ce52f8fb4a4b9704560f735f7ccabb52289a462689fe26bb72', '#4f46e5'),
(2, 'Sarah Chen', 'sarah@example.com', 'scrypt$f0d111ac076cc378a2c7e40387f750ab$adf2344f24d6e145173818e9d6723e1ce4f2ca3478faaa1300bc26692ce3197fbf3c59c8640888ce52f8fb4a4b9704560f735f7ccabb52289a462689fe26bb72', '#059669'),
(3, 'Marcus Vance', 'marcus@example.com', 'scrypt$f0d111ac076cc378a2c7e40387f750ab$adf2344f24d6e145173818e9d6723e1ce4f2ca3478faaa1300bc26692ce3197fbf3c59c8640888ce52f8fb4a4b9704560f735f7ccabb52289a462689fe26bb72', '#d97706');

-- 2. Boards
INSERT INTO boards (id, name, description, owner_id) VALUES 
(1, 'Product Launch 2026', 'Roadmap and sprint tasks for the next generation SaaS platform release', 1),
(2, 'Growth & Marketing', 'Content marketing, PR releases, and social media outreach campaigns', 2);

-- 3. Board Members
-- Board 1: Alex (Owner), Sarah (Member), Marcus (Member)
INSERT INTO board_members (board_id, user_id, role) VALUES 
(1, 1, 'owner'),
(1, 2, 'member'),
(1, 3, 'member');

-- Board 2: Sarah (Owner), Alex (Member)
INSERT INTO board_members (board_id, user_id, role) VALUES 
(2, 2, 'owner'),
(2, 1, 'member');

-- 4. Columns for Board 1
INSERT INTO columns (id, board_id, name, position) VALUES 
(1, 1, 'To Do', 0),
(2, 1, 'In Progress', 1),
(3, 1, 'Code Review', 2),
(4, 1, 'Done', 3);

-- Columns for Board 2
INSERT INTO columns (id, board_id, name, position) VALUES 
(5, 2, 'Ideas & Backlog', 0),
(6, 2, 'Drafting', 1),
(7, 2, 'Published', 2);

-- 5. Tasks for Board 1
-- Overdue task example (due_date in past, not in Done column)
INSERT INTO tasks (id, board_id, column_id, title, description, priority, due_date, assignee_id, created_by, position) VALUES 
(1, 1, 1, 'Design system tokens & typography', 'Establish typography scale, color variables (light/dark), and spacing tokens.', 'High', date('now', '-2 days'), 2, 1, 0),
(2, 1, 1, 'Implement JWT Authentication & RBAC', 'Create auth middleware, token verification, and permission validation for owner/member roles.', 'High', date('now', '+3 days'), 1, 1, 1),
(3, 1, 2, 'Drag and Drop Task Reordering', 'Implement HTML5 Drag and Drop API with integer position renumbering in an atomic SQLite transaction.', 'High', date('now', '+1 day'), 3, 2, 0),
(4, 1, 2, 'Search and Priority Filter Toolbar', 'Real-time client filtering by keyword, priority level, and assignee.', 'Medium', date('now', '+4 days'), 2, 1, 1),
(5, 1, 3, 'Accessible Keyboard Navigation', 'Ensure column movement and card modal can be navigated via keyboard dropdowns.', 'Medium', date('now', '+6 days'), 1, 3, 0),
(6, 1, 4, 'Setup SQLite WAL mode and foreign keys', 'Configure connection pooling, PRAGMA foreign_keys = ON, and WAL journaling for maximum throughput.', 'Low', date('now', '-5 days'), 1, 1, 0),
(7, 1, 4, 'Dark Mode Toggle with Persistence', 'Add CSS variables for theme switching and store preference in localStorage.', 'Low', date('now', '-1 day'), 2, 2, 1);

-- Tasks for Board 2
INSERT INTO tasks (id, board_id, column_id, title, description, priority, due_date, assignee_id, created_by, position) VALUES 
(8, 2, 5, 'Launch Blog Post Draft', 'Draft 1,500-word announcement post covering architectural highlights and performance benchmarks.', 'High', date('now', '+7 days'), 2, 2, 0),
(9, 2, 6, 'Product Hunt Outreach Assets', 'Generate gallery GIFs, tagline, and teaser videos.', 'Medium', date('now', '+2 days'), 1, 2, 0),
(10, 2, 7, 'Press Release Distribution', 'Sent to tech media and community newsletters.', 'Low', date('now', '-3 days'), 2, 2, 0);

-- 6. Comments
INSERT INTO comments (id, task_id, user_id, content, created_at) VALUES 
(1, 1, 1, 'Sarah, please ensure the contrast ratio meets WCAG AAA standards for dark mode.', datetime('now', '-1 day')),
(2, 1, 2, 'Already tested with Lighthouse! All color pairings hit 7:1+ ratio.', datetime('now', '-18 hours')),
(3, 3, 1, 'Transactional renumbering is working reliably without any gap leaks.', datetime('now', '-4 hours'));

-- 7. Activity Log
INSERT INTO activity_log (task_id, user_id, action, created_at) VALUES 
(1, 1, 'Task created', datetime('now', '-3 days')),
(1, 1, 'Assigned to Sarah Chen', datetime('now', '-2 days')),
(3, 2, 'Task created', datetime('now', '-2 days')),
(3, 3, 'Moved task from To Do to In Progress', datetime('now', '-5 hours')),
(6, 1, 'Moved task from Code Review to Done', datetime('now', '-1 day'));
