# ==============================================================================
# Kanban Task Manager - GitHub Repository Setup & Push PowerShell Script
# ==============================================================================

Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  Kanban Task Manager - GitHub Repository Setup Script  " -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host ""

# 1. Check if git is available
$gitCmd = Get-Command git -ErrorAction SilentlyContinue

if (-not $gitCmd) {
    Write-Host "[!] Git is not currently installed or not found in PATH." -ForegroundColor Yellow
    Write-Host "You can quickly install Git on Windows using winget:" -ForegroundColor Gray
    Write-Host "  winget install --id Git.Git -e --source winget" -ForegroundColor Green
    Write-Host "Or download the official Windows installer from: https://git-scm.com/download/win" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Alternatively, open this folder in VS Code and use the built-in 'Publish to GitHub' button!" -ForegroundColor Cyan
    exit 1
}

# 2. Initialize git repository
Write-Host "[1/4] Initializing Git repository..." -ForegroundColor Yellow
if (-not (Test-Path ".git")) {
    git init -b main
} else {
    Write-Host "Git repository already initialized." -ForegroundColor Gray
}

# 3. Ensure git user identity is configured
$gitUser = git config user.name
if (-not $gitUser) {
    Write-Host "Configuring local repository git author identity..." -ForegroundColor Gray
    git config user.name "Developer"
    git config user.email "developer@example.com"
}

# 4. Create structured conventional commits
Write-Host "[2/4] Staging and creating structured commits..." -ForegroundColor Yellow

# Commit 1: Database & Schemas
git add database/ .gitignore .env.example
git commit -m "feat(database): initialize SQLite schema with foreign keys, WAL mode, and seed data" -q

# Commit 2: Backend Architecture & Auth
git add src/ server.js package.json
git commit -m "feat(backend): implement Express REST APIs, JWT authentication, and transactional reordering" -q

# Commit 3: Interactive Frontend & Themes
git add public/
git commit -m "feat(frontend): build responsive Kanban UI with HTML5 Drag & Drop, modals, and light/dark theme" -q

# Commit 4: Testing & Documentation
git add tests/ README.md ORDERING_LOGIC.md ER_DIAGRAM.md Kanban_API.postman_collection.json setup-git.bat setup-git.ps1
git commit -m "docs(all): add comprehensive architecture docs, automated test suite, and Postman collection" -q

# Stage any remaining files
git add .
git commit -m "chore: finalize project release and documentation" -q

Write-Host "`n[3/4] Commit history successfully created:" -ForegroundColor Green
git log --oneline -n 5

# 5. Remote and Push
Write-Host "`n[4/4] Remote Push to GitHub" -ForegroundColor Yellow
$repoUrl = Read-Host "Enter your GitHub Repository URL (e.g. https://github.com/username/kanban-task-manager.git)"

if ([string]::IsNullOrWhiteSpace($repoUrl)) {
    Write-Host "`n[INFO] No repository URL provided." -ForegroundColor Gray
    Write-Host "Whenever you create your repo on GitHub, push with these commands:" -ForegroundColor Cyan
    Write-Host "  git remote add origin <YOUR_GITHUB_REPO_URL>" -ForegroundColor Green
    Write-Host "  git branch -M main" -ForegroundColor Green
    Write-Host "  git push -u origin main" -ForegroundColor Green
} else {
    git remote remove origin 2>$null
    git remote add origin $repoUrl
    git branch -M main
    Write-Host "Pushing code to GitHub..." -ForegroundColor Yellow
    git push -u origin main
    if ($LASTEXITCODE -eq 0) {
        Write-Host "`n[SUCCESS] Code successfully published to GitHub!" -ForegroundColor Green
    } else {
        Write-Host "`n[NOTICE] Push failed or authentication required. Run 'git push -u origin main' in your terminal." -ForegroundColor Yellow
    }
}
