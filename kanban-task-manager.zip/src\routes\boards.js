// ============================================================================
// Boards Routes (/api/boards)
// ============================================================================

const { 
  queryAll, 
  queryOne, 
  execute, 
  transaction 
} = require('../../database/db');
const { 
  requireAuth, 
  requireBoardAccess 
} = require('../middleware/auth');
const { 
  sanitizeHtml, 
  isValidEmail, 
  success, 
  error 
} = require('../utils/helpers');

module.exports = function boardRoutes(router) {
  /**
   * GET /api/boards
   * List all boards the authenticated user owns or is a member of
   */
  router.get('/', requireAuth, (req, res) => {
    try {
      const sql = `
        SELECT 
          b.id,
          b.name,
          b.description,
          b.owner_id,
          b.created_at,
          bm.role,
          u.name AS owner_name,
          u.email AS owner_email,
          (SELECT COUNT(*) FROM tasks t WHERE t.board_id = b.id) AS task_count,
          (SELECT COUNT(*) FROM board_members bm_sub WHERE bm_sub.board_id = b.id) AS member_count
        FROM boards b
        JOIN board_members bm ON b.id = bm.board_id
        JOIN users u ON b.owner_id = u.id
        WHERE bm.user_id = ?
        ORDER BY b.created_at DESC
      `;
      const boards = queryAll(sql, [req.user.id]);
      return success(res, { boards });
    } catch (err) {
      console.error('List boards error:', err);
      return error(res, 'Failed to retrieve boards.', 500);
    }
  });

  /**
   * POST /api/boards
   * Create a new board with 3 default columns (To Do, In Progress, Done)
   */
  router.post('/', requireAuth, (req, res) => {
    try {
      const { name, description } = req.body || {};
      if (!name || !name.trim()) {
        return error(res, 'Board name is required.', 400);
      }

      const boardName = sanitizeHtml(name.trim());
      const boardDesc = sanitizeHtml((description || '').trim());

      const newBoard = transaction((db) => {
        // 1. Insert board
        const bRes = db.execute(
          'INSERT INTO boards (name, description, owner_id) VALUES (?, ?, ?)',
          [boardName, boardDesc, req.user.id]
        );
        const boardId = bRes.lastInsertRowid;

        // 2. Add creator as owner member
        db.execute(
          'INSERT INTO board_members (board_id, user_id, role) VALUES (?, ?, ?)',
          [boardId, req.user.id, 'owner']
        );

        // 3. Create default 3 columns
        const defaultColumns = ['To Do', 'In Progress', 'Done'];
        defaultColumns.forEach((colName, index) => {
          db.execute(
            'INSERT INTO columns (board_id, name, position) VALUES (?, ?, ?)',
            [boardId, colName, index]
          );
        });

        return db.queryOne('SELECT * FROM boards WHERE id = ?', [boardId]);
      });

      return success(res, { board: newBoard }, 201);
    } catch (err) {
      console.error('Create board error:', err);
      return error(res, 'Failed to create board.', 500);
    }
  });

  /**
   * GET /api/boards/:id
   * Get full board details: columns, ordered tasks, members
   */
  router.get('/:id', requireAuth, requireBoardAccess('member'), (req, res) => {
    try {
      const boardId = req.board.id;

      // 1. Columns ordered by position ASC
      const columns = queryAll(
        'SELECT id, board_id, name, position, created_at FROM columns WHERE board_id = ? ORDER BY position ASC',
        [boardId]
      );

      // Identify done column ID (last column position)
      const lastColumnId = columns.length > 0 ? columns[columns.length - 1].id : null;

      // 2. Tasks with assignee info and comment count
      const tasksSql = `
        SELECT 
          t.id,
          t.board_id,
          t.column_id,
          t.title,
          t.description,
          t.priority,
          t.due_date,
          t.assignee_id,
          t.created_by,
          t.position,
          t.created_at,
          t.updated_at,
          u.name AS assignee_name,
          u.email AS assignee_email,
          u.avatar_color AS assignee_avatar,
          creator.name AS creator_name,
          (SELECT COUNT(*) FROM comments c WHERE c.task_id = t.id) AS comment_count
        FROM tasks t
        LEFT JOIN users u ON t.assignee_id = u.id
        LEFT JOIN users creator ON t.created_by = creator.id
        WHERE t.board_id = ?
        ORDER BY t.column_id ASC, t.position ASC
      `;
      const rawTasks = queryAll(tasksSql, [boardId]);

      const today = new Date().toISOString().split('T')[0];

      const tasks = rawTasks.map(task => {
        const isDone = task.column_id === lastColumnId;
        const isOverdue = Boolean(task.due_date && task.due_date < today && !isDone);
        return {
          ...task,
          is_overdue: isOverdue
        };
      });

      // 3. Board members
      const membersSql = `
        SELECT 
          u.id,
          u.name,
          u.email,
          u.avatar_color,
          bm.role,
          bm.created_at AS joined_at
        FROM board_members bm
        JOIN users u ON bm.user_id = u.id
        WHERE bm.board_id = ?
        ORDER BY CASE WHEN bm.role = 'owner' THEN 0 ELSE 1 END, u.name ASC
      `;
      const members = queryAll(membersSql, [boardId]);

      return success(res, {
        board: {
          ...req.board,
          role: req.boardRole
        },
        columns,
        tasks,
        members
      });
    } catch (err) {
      console.error('Get board error:', err);
      return error(res, 'Failed to fetch board details.', 500);
    }
  });

  /**
   * PUT /api/boards/:id
   * Rename or update board (Owner only)
   */
  router.put('/:id', requireAuth, requireBoardAccess('owner'), (req, res) => {
    try {
      const { name, description } = req.body || {};
      if (!name || !name.trim()) {
        return error(res, 'Board name is required.', 400);
      }

      const boardName = sanitizeHtml(name.trim());
      const boardDesc = sanitizeHtml((description || '').trim());

      execute(
        'UPDATE boards SET name = ?, description = ? WHERE id = ?',
        [boardName, boardDesc, req.board.id]
      );

      const updated = queryOne('SELECT * FROM boards WHERE id = ?', [req.board.id]);
      return success(res, { board: updated });
    } catch (err) {
      console.error('Update board error:', err);
      return error(res, 'Failed to update board.', 500);
    }
  });

  /**
   * DELETE /api/boards/:id
   * Delete board and all cascaded data (Owner only)
   */
  router.delete('/:id', requireAuth, requireBoardAccess('owner'), (req, res) => {
    try {
      execute('DELETE FROM boards WHERE id = ?', [req.board.id]);
      return success(res, { message: 'Board deleted successfully.' });
    } catch (err) {
      console.error('Delete board error:', err);
      return error(res, 'Failed to delete board.', 500);
    }
  });

  /**
   * POST /api/boards/:id/members
   * Add a member to the board by email (Owner only)
   */
  router.post('/:id/members', requireAuth, requireBoardAccess('owner'), (req, res) => {
    try {
      const { email } = req.body || {};
      if (!email || !isValidEmail(email)) {
        return error(res, 'A valid email address is required.', 400);
      }

      const trimmedEmail = email.trim().toLowerCase();
      const userToAdd = queryOne('SELECT id, name, email, avatar_color FROM users WHERE email = ?', [trimmedEmail]);
      if (!userToAdd) {
        return error(res, `No user found with email "${trimmedEmail}". They must register first.`, 404);
      }

      const existingMember = queryOne(
        'SELECT role FROM board_members WHERE board_id = ? AND user_id = ?',
        [req.board.id, userToAdd.id]
      );
      if (existingMember) {
        return error(res, 'User is already a member of this board.', 409);
      }

      execute(
        'INSERT INTO board_members (board_id, user_id, role) VALUES (?, ?, ?)',
        [req.board.id, userToAdd.id, 'member']
      );

      return success(res, {
        message: 'Member added successfully.',
        member: {
          id: userToAdd.id,
          name: userToAdd.name,
          email: userToAdd.email,
          avatar_color: userToAdd.avatar_color,
          role: 'member'
        }
      }, 201);
    } catch (err) {
      console.error('Add member error:', err);
      return error(res, 'Failed to add board member.', 500);
    }
  });

  /**
   * DELETE /api/boards/:id/members/:userId
   * Remove member from board (Owner only)
   */
  router.delete('/:id/members/:userId', requireAuth, requireBoardAccess('owner'), (req, res) => {
    try {
      const targetUserId = parseInt(req.params.userId, 10);
      if (isNaN(targetUserId)) {
        return error(res, 'Invalid user ID.', 400);
      }

      if (targetUserId === req.board.owner_id) {
        return error(res, 'The board owner cannot be removed from the board.', 400);
      }

      const member = queryOne(
        'SELECT id FROM board_members WHERE board_id = ? AND user_id = ?',
        [req.board.id, targetUserId]
      );
      if (!member) {
        return error(res, 'User is not a member of this board.', 404);
      }

      transaction((db) => {
        // Remove from board_members
        db.execute(
          'DELETE FROM board_members WHERE board_id = ? AND user_id = ?',
          [req.board.id, targetUserId]
        );
        // Unassign any tasks assigned to this user on this board
        db.execute(
          'UPDATE tasks SET assignee_id = NULL WHERE board_id = ? AND assignee_id = ?',
          [req.board.id, targetUserId]
        );
      });

      return success(res, { message: 'Member removed successfully.' });
    } catch (err) {
      console.error('Remove member error:', err);
      return error(res, 'Failed to remove member.', 500);
    }
  });

  /**
   * POST /api/boards/:id/columns
   * Add a new column to the board (Owner or Member)
   */
  router.post('/:id/columns', requireAuth, requireBoardAccess('member'), (req, res) => {
    try {
      const { name } = req.body || {};
      if (!name || !name.trim()) {
        return error(res, 'Column name is required.', 400);
      }

      const colName = sanitizeHtml(name.trim());
      const posRow = queryOne(
        'SELECT COALESCE(MAX(position), -1) + 1 AS next_pos FROM columns WHERE board_id = ?',
        [req.board.id]
      );
      const position = posRow ? posRow.next_pos : 0;

      const result = execute(
        'INSERT INTO columns (board_id, name, position) VALUES (?, ?, ?)',
        [req.board.id, colName, position]
      );

      const column = queryOne('SELECT * FROM columns WHERE id = ?', [result.lastInsertRowid]);
      return success(res, { column }, 201);
    } catch (err) {
      console.error('Add column error:', err);
      return error(res, 'Failed to add column.', 500);
    }
  });

  /**
   * GET /api/boards/:id/tasks?q=&priority=&assignee=
   * Search and filter tasks on a board
   */
  router.get('/:id/tasks', requireAuth, requireBoardAccess('member'), (req, res) => {
    try {
      const boardId = req.board.id;
      const { q, priority, assignee } = req.query || {};

      let sql = `
        SELECT 
          t.id,
          t.board_id,
          t.column_id,
          t.title,
          t.description,
          t.priority,
          t.due_date,
          t.assignee_id,
          t.created_by,
          t.position,
          t.created_at,
          t.updated_at,
          u.name AS assignee_name,
          u.email AS assignee_email,
          u.avatar_color AS assignee_avatar,
          c.name AS column_name,
          (SELECT COUNT(*) FROM comments comm WHERE comm.task_id = t.id) AS comment_count
        FROM tasks t
        JOIN columns c ON t.column_id = c.id
        LEFT JOIN users u ON t.assignee_id = u.id
        WHERE t.board_id = ?
      `;
      const params = [boardId];

      if (q && q.trim()) {
        const queryTerm = `%${q.trim()}%`;
        sql += ' AND (t.title LIKE ? OR t.description LIKE ?)';
        params.push(queryTerm, queryTerm);
      }

      if (priority && ['Low', 'Medium', 'High'].includes(priority)) {
        sql += ' AND t.priority = ?';
        params.push(priority);
      }

      if (assignee) {
        if (assignee === 'me') {
          sql += ' AND t.assignee_id = ?';
          params.push(req.user.id);
        } else if (assignee === 'unassigned') {
          sql += ' AND t.assignee_id IS NULL';
        } else {
          const parsedAssigneeId = parseInt(assignee, 10);
          if (!isNaN(parsedAssigneeId)) {
            sql += ' AND t.assignee_id = ?';
            params.push(parsedAssigneeId);
          }
        }
      }

      sql += ' ORDER BY t.column_id ASC, t.position ASC';

      const tasks = queryAll(sql, params);
      return success(res, { tasks });
    } catch (err) {
      console.error('Filter tasks error:', err);
      return error(res, 'Failed to filter tasks.', 500);
    }
  });

  return router;
};
