# Kanban Flow - Task Management Application

A full-stack, Kanban-style task management web application inspired by Trello and Jira. Built with modern Vanilla JavaScript, Node.js, Express.js, SQLite with Foreign Keys and WAL mode, and JWT token authentication.

---

## Key Features

### 1. Authentication & Security
- **Secure Registration & Login**: User registration with unique email validation and password hashing (bcrypt / scrypt).
- **Stateless JWT Sessions**: 7-day signed JWT tokens passed via `Authorization: Bearer <token>`.
- **Route Protection**: Automatic client redirect for unauthenticated users; immediate token purging upon logout or expiry.
- **XSS Prevention & Parameterized Queries**: Strict sanitization of all user input and 100% parameterized SQL prepared statements to eliminate SQL injection.

### 2. Boards & Workspaces
- **Workspace Dashboard**: Displays all boards where the user is an owner or member, with real-time task counts and member metrics.
- **Default Column Initialization**: Creating a board automatically bootstraps 3 default columns: **To Do**, **In Progress**, and **Done**.
- **Role-Based Access Control (RBAC)**:
  - **Board Owner**: Full administrative control (rename/delete board, add/remove members by email, delete columns).
  - **Board Member**: Create, edit, and move tasks; reorder columns; post and delete their own comments.
  - **Non-Member**: Immediate `403 Forbidden` response.

### 3. Columns & Horizontal Layout
- **Horizontal Canvas**: Smooth scrolling container with responsive, fixed-width column cards.
- **Dynamic Columns**: Add, rename, or delete columns with automatic cascading task cleanup.
- **Accessible Reordering**: Move columns horizontally using drag & drop or dedicated left/right arrow buttons.

### 4. Tasks & Drag and Drop
- **HTML5 Drag & Drop**: Fluid card movement within the same column or across columns with insertion drop-indicators.
- **Transactional Renumbering**: Contiguous integer ordering (0..N-1) guaranteed by atomic SQLite transactions (`BEGIN IMMEDIATE ... COMMIT`).
- **Visual Priority Indicators**: High (Crimson), Medium (Amber), and Low (Emerald) color-coded badges.
- **Overdue Task Highlighting**: Tasks whose due date has passed that are not in the final column display a prominent red **Overdue** pill with border highlighting.
- **Member Avatars**: Visual initials circle with color deterministically generated from user email.
- **Accessibility Dropdown**: Move cards to any column from a dropdown menu without requiring drag-and-drop.

### 5. Comments, Search & Activity Log
- **Collaborative Comments**: Real-time comment stream on tasks with author avatar and timestamp.
- **Author Permissions**: Users can only delete their own comments (enforced both client-side and server-side).
- **Search & Filter Toolbar**: Real-time keyword search across titles and descriptions, combined with priority and assignee filters ("Assigned to Me", "Unassigned", or specific member).
- **Audit Activity Trail**: Automatic audit logging when tasks are created, moved between columns, priority modified, or reassigned.

### 6. Modern UI & Dark Mode
- **Dual Theme Support**: Beautiful light and dark themes with CSS custom properties and instant `localStorage` persistence.
- **Zero-Flicker Bootstrapping**: Theme applied in `head` before DOM render to prevent theme flashing.
- **Responsive Design**: Adapts cleanly from mobile viewports to ultra-wide displays.

---

## Technology Stack

| Layer | Technologies |
| :--- | :--- |
| **Frontend** | HTML5, Modern CSS3 (Variables, Flexbox, Grid), Vanilla JavaScript (ES6+, Fetch API, HTML5 Drag & Drop) |
| **Backend** | Node.js (v18+ / v22+ / v24+), Express.js (with built-in zero-dependency fallback) |
| **Database** | SQLite3 with Foreign Keys explicitly enabled (`PRAGMA foreign_keys = ON;`) and WAL Mode |
| **Security** | bcrypt / scrypt password hashing, HS256 JWT tokens |
| **Testing** | Automated in-memory end-to-end test suite (`tests/api.test.js`) |
| **API Tools** | Postman collection (`Kanban_API.postman_collection.json`) |

---

## Project Structure

```
kanban-task-manager/
├── package.json                          # NPM dependencies and scripts
├── server.js                             # Application entry point & router setup
├── .env.example                          # Environment configuration template
├── README.md                             # Project overview, setup, and API docs
├── ORDERING_LOGIC.md                     # Deep dive on task/column positioning
├── ER_DIAGRAM.md                         # Mermaid ER diagram & database dictionary
├── Kanban_API.postman_collection.json    # Ready-to-import Postman collection
├── database/
│   ├── schema.sql                        # SQLite schema DDL with foreign keys
│   ├── seed.sql                          # Initial seed data for users, boards, tasks
│   ├── db.js                             # Database wrapper with transaction support
│   └── seed.js                           # Seeding execution script
├── src/
│   ├── middleware/
│   │   └── auth.js                       # JWT auth & RBAC permissions middleware
│   ├── routes/
│   │   ├── auth.js                       # Authentication endpoints (/api/auth)
│   │   ├── boards.js                     # Boards endpoints (/api/boards)
│   │   ├── columns.js                    # Columns endpoints (/api/columns)
│   │   ├── tasks.js                      # Tasks endpoints (/api/tasks)
│   │   └── comments.js                   # Comments endpoints (/api/comments)
│   └── utils/
│       ├── crypto.js                     # Password hashing & JWT signing
│       ├── helpers.js                    # Sanitization, validation & formatting
│       └── mini-express.js               # Zero-dependency Express compatibility
├── public/
│   ├── index.html                        # App entry point & auth router
│   ├── login.html                        # Sign in page with 1-click demo login
│   ├── register.html                     # User registration form
│   ├── dashboard.html                    # Boards overview & board creator
│   ├── board.html                        # Interactive Kanban board view
│   ├── css/
│   │   ├── style.css                     # Main styling with light & dark themes
│   │   └── auth.css                      # Authentication views layout
│   └── js/
│       ├── api.js                        # Fetch wrapper with JWT headers & toasts
│       ├── auth.js                       # Session management & route protection
│       ├── theme.js                      # Theme switcher & persistence
│       ├── dashboard.js                  # Dashboard controller
│       └── board.js                      # Kanban drag & drop, filtering & modals
└── tests/
    └── api.test.js                       # End-to-end automated test suite
```

---

## Quick Start & Setup

### Prerequisites
- Node.js (v18.0.0 or higher)

### 1. Installation
Clone the repository and enter the directory:
```bash
git clone https://github.com/your-username/kanban-task-manager.git
cd kanban-task-manager
```

Install dependencies (optional—the project is engineered to run both with standard npm dependencies or in zero-dependency mode using Node.js built-ins):
```bash
npm install
```

### 2. Database Initialization & Seeding
The database schema and demo seed data are initialized automatically on the first server launch. To re-seed manually at any time:
```bash
npm run seed
# Or: node database/seed.js
```

### 3. Start the Server
```bash
npm start
# Or: node server.js
```

Open your browser and navigate to:
```
http://localhost:3000
```

---

## Demo Accounts

All demo accounts share the password: `password123`. The login screen includes **1-click quick fill buttons** for instant access:

| Name | Email | Role in Demo Board | Primary Color |
| :--- | :--- | :--- | :--- |
| **Alex Rivers** | `alex@example.com` | Owner of *Product Launch 2026* | Indigo (`#4f46e5`) |
| **Sarah Chen** | `sarah@example.com` | Owner of *Growth & Marketing*, Member of Board 1 | Emerald (`#059669`) |
| **Marcus Vance** | `marcus@example.com` | Member of *Product Launch 2026* | Amber (`#d97706`) |

---

## REST API Reference

All protected endpoints require the header:
```
Authorization: Bearer <jwt_token>
```

### 1. Authentication
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `POST` | `/api/auth/register` | Register new user account | Public |
| `POST` | `/api/auth/login` | Login and obtain JWT session token | Public |
| `GET` | `/api/auth/me` | Fetch authenticated user profile | Authenticated |

### 2. Boards
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/boards` | List user's boards with task & member counts | Authenticated |
| `POST` | `/api/boards` | Create board with default columns (To Do, In Progress, Done) | Authenticated |
| `GET` | `/api/boards/:id` | Get board details, columns, ordered tasks, and members | Board Member |
| `PUT` | `/api/boards/:id` | Rename / update board details | Board Owner |
| `DELETE` | `/api/boards/:id` | Delete board and all cascaded data | Board Owner |
| `POST` | `/api/boards/:id/members` | Add member to board by registered email | Board Owner |
| `DELETE` | `/api/boards/:id/members/:userId` | Remove member from board | Board Owner |
| `GET` | `/api/boards/:id/tasks` | Search and filter tasks (`?q=&priority=&assignee=`) | Board Member |

### 3. Columns
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `POST` | `/api/boards/:id/columns` | Append a new column to the board | Board Member |
| `PUT` | `/api/columns/:id` | Rename or reorder column position | Board Member |
| `DELETE` | `/api/columns/:id` | Delete column (cascades to tasks) | Board Owner |

### 4. Tasks
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `POST` | `/api/columns/:id/tasks` | Create task inside column | Board Member |
| `GET` | `/api/tasks/:id` | Fetch task details, comments, and audit trail | Board Member |
| `PUT` | `/api/tasks/:id` | Update task title, description, priority, due date, assignee | Board Member |
| `PATCH` | `/api/tasks/:id/move` | Move task to new column and/or reorder position | Board Member |
| `DELETE` | `/api/tasks/:id` | Delete task with contiguous renumbering | Board Member |

### 5. Comments
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `POST` | `/api/tasks/:id/comments` | Post comment on task | Board Member |
| `DELETE` | `/api/comments/:id` | Delete comment | Author Only |

---

## Running Automated Tests

The automated test suite runs against an isolated SQLite test database and validates all 24 core operations (registration, authentication, board initialization, permissions, cross-column moving, transactional reordering, author-only deletion, and search):

```bash
npm test
# Or: node tests/api.test.js
```

Expected output:
```
====================================================
 ALL TESTS PASSED: 24 Passed, 0 Failed 
====================================================
```

---

## Postman Collection

Import `Kanban_API.postman_collection.json` into Postman:
1. Open Postman $\rightarrow$ Click **Import**.
2. Select `Kanban_API.postman_collection.json`.
3. The collection is pre-configured with the `{{baseUrl}}` variable set to `http://localhost:3000`.
4. Executing the **Login User** request automatically saves the received JWT into the collection variable `{{token}}`, enabling immediate testing of all protected endpoints without manual copy-pasting.

---

## License
MIT License. Open source and free to use for educational and commercial projects.
