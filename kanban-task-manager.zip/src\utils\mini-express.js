// ============================================================================
// Mini-Express: Zero-Dependency Drop-in Express Compatibility Layer
// Powered by Node.js built-in `node:http`, `node:fs`, and `node:path`.
// ============================================================================

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8'
};

function pathToRegexp(routePath) {
  const keys = [];
  const pattern = routePath
    .replace(/\/:([a-zA-Z0-9_]+)/g, (_, key) => {
      keys.push(key);
      return '/([^/]+)';
    })
    .replace(/\*/g, '.*');
  const regex = new RegExp(`^${pattern}$`);
  return { regex, keys };
}

class Router {
  constructor() {
    this.routes = [];
  }

  addRoute(method, routePath, ...handlers) {
    const flatHandlers = handlers.flat();
    const { regex, keys } = pathToRegexp(routePath);
    this.routes.push({
      method: method.toUpperCase(),
      path: routePath,
      regex,
      keys,
      handlers: flatHandlers
    });
  }

  get(path, ...handlers) { this.addRoute('GET', path, ...handlers); return this; }
  post(path, ...handlers) { this.addRoute('POST', path, ...handlers); return this; }
  put(path, ...handlers) { this.addRoute('PUT', path, ...handlers); return this; }
  patch(path, ...handlers) { this.addRoute('PATCH', path, ...handlers); return this; }
  delete(path, ...handlers) { this.addRoute('DELETE', path, ...handlers); return this; }
}

function express() {
  const middlewares = [];
  const routers = [];

  const app = {
    use(prefixOrFn, ...handlers) {
      if (typeof prefixOrFn === 'string') {
        const prefix = prefixOrFn.endsWith('/') ? prefixOrFn.slice(0, -1) : prefixOrFn;
        handlers.forEach(h => {
          if (h instanceof Router) {
            routers.push({ prefix, router: h });
          } else if (typeof h === 'function') {
            middlewares.push({ prefix, fn: h });
          }
        });
      } else if (prefixOrFn instanceof Router) {
        routers.push({ prefix: '', router: prefixOrFn });
      } else if (typeof prefixOrFn === 'function') {
        middlewares.push({ prefix: '', fn: prefixOrFn });
        handlers.forEach(h => middlewares.push({ prefix: '', fn: h }));
      }
      return app;
    },

    get(path, ...handlers) {
      const r = new Router();
      r.get(path, ...handlers);
      routers.push({ prefix: '', router: r });
      return app;
    },

    listen(port, callback) {
      const server = http.createServer(async (req, res) => {
        // Enhance Request
        const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
        req.pathname = parsedUrl.pathname;
        req.query = Object.fromEntries(parsedUrl.searchParams.entries());
        req.params = {};
        req.body = {};

        // Enhance Response
        res.statusCode = 200;
        res.status = function (code) {
          res.statusCode = code;
          return res;
        };

        res.json = function (data) {
          if (res.writableEnded) return;
          res.setHeader('Content-Type', 'application/json; charset=utf-8');
          res.end(JSON.stringify(data));
        };

        res.send = function (data) {
          if (res.writableEnded) return;
          if (typeof data === 'object' && data !== null) {
            return res.json(data);
          }
          res.end(String(data));
        };

        res.sendFile = function (filePath) {
          if (res.writableEnded) return;
          if (!fs.existsSync(filePath)) {
            res.status(404).send('File Not Found');
            return;
          }
          const ext = path.extname(filePath).toLowerCase();
          const contentType = MIME_TYPES[ext] || 'application/octet-stream';
          res.setHeader('Content-Type', contentType);
          fs.createReadStream(filePath).pipe(res);
        };

        // Parse JSON body if present
        if (['POST', 'PUT', 'PATCH'].includes(req.method)) {
          const contentType = req.headers['content-type'] || '';
          if (contentType.includes('application/json')) {
            try {
              const bodyChunks = [];
              for await (const chunk of req) {
                bodyChunks.push(chunk);
              }
              const rawBody = Buffer.concat(bodyChunks).toString('utf8');
              if (rawBody.trim()) {
                req.body = JSON.parse(rawBody);
              }
            } catch (jsonErr) {
              return res.status(400).json({ success: false, error: 'Malformed JSON payload.' });
            }
          }
        }

        // Run matching handlers
        const pipeline = [];

        // 1. Middlewares
        middlewares.forEach(mw => {
          if (!mw.prefix || req.pathname.startsWith(mw.prefix)) {
            pipeline.push(mw.fn);
          }
        });

        // 2. Matching Route
        let matchedRoute = null;
        let matchedParams = {};

        for (const { prefix, router } of routers) {
          if (req.pathname.startsWith(prefix)) {
            const subPath = req.pathname.slice(prefix.length) || '/';
            for (const r of router.routes) {
              if (r.method === req.method) {
                const match = subPath.match(r.regex);
                if (match) {
                  matchedRoute = r;
                  r.keys.forEach((key, index) => {
                    matchedParams[key] = decodeURIComponent(match[index + 1]);
                  });
                  break;
                }
              }
            }
            if (matchedRoute) break;
          }
        }

        if (matchedRoute) {
          req.params = matchedParams;
          pipeline.push(...matchedRoute.handlers);
        }

        let step = 0;
        function next(err) {
          if (res.writableEnded) return;
          if (err) {
            console.error('Unhandled request error:', err);
            return res.status(500).json({ success: false, error: 'Internal Server Error' });
          }
          if (step < pipeline.length) {
            const handler = pipeline[step++];
            try {
              const maybePromise = handler(req, res, next);
              if (maybePromise && typeof maybePromise.catch === 'function') {
                maybePromise.catch(next);
              }
            } catch (syncErr) {
              next(syncErr);
            }
          } else {
            // Not handled by any route
            if (!res.writableEnded) {
              res.status(404).json({ success: false, error: `Cannot ${req.method} ${req.pathname}` });
            }
          }
        }

        next();
      });

      return server.listen(port, callback);
    }
  };

  return app;
}

express.Router = () => new Router();

express.json = () => (req, res, next) => next();

express.static = (staticDir) => {
  return (req, res, next) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      return next();
    }
    let targetPath = path.join(staticDir, req.pathname);
    if (fs.existsSync(targetPath) && fs.statSync(targetPath).isDirectory()) {
      targetPath = path.join(targetPath, 'index.html');
    }
    if (fs.existsSync(targetPath) && fs.statSync(targetPath).isFile()) {
      return res.sendFile(targetPath);
    }
    next();
  };
};

module.exports = express;
