// ============================================================================
// Client-Side Authentication State Manager
// ============================================================================

const auth = {
  getToken() {
    return localStorage.getItem('kanban_token');
  },

  getUser() {
    try {
      return JSON.parse(localStorage.getItem('kanban_user') || 'null');
    } catch (e) {
      return null;
    }
  },

  isAuthenticated() {
    return Boolean(this.getToken() && this.getUser());
  },

  setSession(token, user) {
    localStorage.setItem('kanban_token', token);
    localStorage.setItem('kanban_user', JSON.stringify(user));
  },

  logout() {
    localStorage.removeItem('kanban_token');
    localStorage.removeItem('kanban_user');
    window.location.href = '/login.html';
  },

  /**
   * Protect private pages (e.g. dashboard, board)
   */
  requireAuth() {
    if (!this.isAuthenticated()) {
      window.location.href = '/login.html';
    }
  },

  /**
   * Redirect away from login/register if already logged in
   */
  redirectIfAuthenticated() {
    if (this.isAuthenticated()) {
      window.location.href = '/dashboard.html';
    }
  },

  /**
   * Helper to get initials
   */
  getInitials(name) {
    if (!name) return '?';
    const parts = name.trim().split(/\s+/);
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  },

  /**
   * Render authenticated user controls in navbar
   */
  renderNavbar() {
    const userContainer = document.getElementById('nav-user-container');
    if (!userContainer) return;

    const user = this.getUser();
    if (!user) return;

    userContainer.innerHTML = `
      <div class="user-badge" title="${user.email}">
        <div class="avatar-circle" style="background-color: ${user.avatar_color || '#4f46e5'}">
          ${this.getInitials(user.name)}
        </div>
        <span style="font-weight:600;">${user.name}</span>
      </div>
      <button class="btn btn-secondary btn-sm" id="logout-btn" title="Sign out of account">
        <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
        </svg>
        <span>Logout</span>
      </button>
    `;

    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', () => {
        auth.logout();
      });
    }
  }
};
