const { seedDb } = require('./db');

try {
  seedDb();
  console.log('Database seeding completed successfully!');
  process.exit(0);
} catch (err) {
  console.error('Seeding failed:', err);
  process.exit(1);
}
