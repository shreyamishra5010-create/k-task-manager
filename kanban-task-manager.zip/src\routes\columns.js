// ============================================================================
// Columns Routes (/api/columns)
// ============================================================================

const { 
  queryAll, 
  queryOne, 
  execute, 
  transaction 
} = require('../../database/db');
const { 
  requireAuth, 
  requireColumnAccess 
} = require('../middleware/auth');
const { 
  sanitizeHtml, 
  success, 
  error 
} = require('../utils/helpers');

module.exports = function columnRoutes(router) {
  /**
   * PUT /api/columns/:id
   * Rename and/or reorder a column
   */
  router.put('/:id', requireAuth, requireColumnAccess('member'), (req, res) => {
    try {
      const { name, position } = req.body || {};
      const column = req.column;
      const boardId = column.board_id;

      // Handle reordering if position is provided
      if (typeof position === 'number' && position !== column.position) {
        transaction((db) => {
          const oldPos = column.position;
          const newPos = position;

          // Fetch all columns for this board ordered by position
          const allCols = db.queryAll(
            'SELECT id, position FROM columns WHERE board_id = ? ORDER BY position ASC',
            [boardId]
          );

          const maxPos = allCols.length - 1;
          const targetPos = Math.max(0, Math.min(newPos, maxPos));

          if (oldPos < targetPos) {
            // Shift down columns between oldPos + 1 and targetPos
            db.execute(
              'UPDATE columns SET position = position - 1 WHERE board_id = ? AND position > ? AND position <= ?',
              [boardId, oldPos, targetPos]
            );
          } else if (oldPos > targetPos) {
            // Shift up columns between targetPos and oldPos - 1
            db.execute(
              'UPDATE columns SET position = position + 1 WHERE board_id = ? AND position >= ? AND position < ?',
              [boardId, targetPos, oldPos]
            );
          }

          db.execute('UPDATE columns SET position = ? WHERE id = ?', [targetPos, column.id]);
        });
      }

      // Handle renaming if name is provided
      if (name && name.trim()) {
        const cleanName = sanitizeHtml(name.trim());
        execute('UPDATE columns SET name = ? WHERE id = ?', [cleanName, column.id]);
      }

      const updated = queryOne('SELECT * FROM columns WHERE id = ?', [column.id]);
      return success(res, { column: updated });
    } catch (err) {
      console.error('Update column error:', err);
      return error(res, 'Failed to update column.', 500);
    }
  });

  /**
   * DELETE /api/columns/:id
   * Delete column (Owner or Member depending on role)
   */
  router.delete('/:id', requireAuth, requireColumnAccess('owner'), (req, res) => {
    try {
      const column = req.column;
      const boardId = column.board_id;

      transaction((db) => {
        // Delete the column (cascades to tasks due to ON DELETE CASCADE)
        db.execute('DELETE FROM columns WHERE id = ?', [column.id]);

        // Renumber remaining columns to maintain compact 0..n-1 positions
        const remaining = db.queryAll(
          'SELECT id FROM columns WHERE board_id = ? ORDER BY position ASC',
          [boardId]
        );
        remaining.forEach((col, idx) => {
          db.execute('UPDATE columns SET position = ? WHERE id = ?', [idx, col.id]);
        });
      });

      return success(res, { message: 'Column deleted successfully.' });
    } catch (err) {
      console.error('Delete column error:', err);
      return error(res, 'Failed to delete column.', 500);
    }
  });

  /**
   * POST /api/columns/:id/tasks
   * Create a new task within a column
   */
  router.post('/:id/tasks', requireAuth, requireColumnAccess('member'), (req, res) => {
    try {
      const { title, description, priority, due_date, assignee_id } = req.body || {};

      if (!title || !title.trim()) {
        return error(res, 'Task title is required.', 400);
      }

      const taskTitle = sanitizeHtml(title.trim());
      const taskDesc = sanitizeHtml((description || '').trim());
      const taskPriority = ['Low', 'Medium', 'High'].includes(priority) ? priority : 'Medium';
      const taskDueDate = due_date && /^\d{4}-\d{2}-\d{2}$/.test(due_date) ? due_date : null;

      let validAssigneeId = null;
      if (assignee_id) {
        const parsed = parseInt(assignee_id, 10);
        if (!isNaN(parsed)) {
          // Verify assignee is a member of the board
          const member = queryOne(
            'SELECT user_id FROM board_members WHERE board_id = ? AND user_id = ?',
            [req.boardId, parsed]
          );
          if (member) validAssigneeId = parsed;
        }
      }

      const newTask = transaction((db) => {
        // Calculate next position in this column
        const posRow = db.queryOne(
          'SELECT COALESCE(MAX(position), -1) + 1 AS next_pos FROM tasks WHERE column_id = ?',
          [req.column.id]
        );
        const position = posRow ? posRow.next_pos : 0;

        const insertRes = db.execute(
          `INSERT INTO tasks 
            (board_id, column_id, title, description, priority, due_date, assignee_id, created_by, position) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            req.boardId,
            req.column.id,
            taskTitle,
            taskDesc,
            taskPriority,
            taskDueDate,
            validAssigneeId,
            req.user.id,
            position
          ]
        );

        const taskId = insertRes.lastInsertRowid;

        // Log task creation activity
        db.execute(
          'INSERT INTO activity_log (task_id, user_id, action) VALUES (?, ?, ?)',
          [taskId, req.user.id, `Created task in "${req.column.name}"`]
        );

        return db.queryOne(
          `SELECT t.*, u.name AS assignee_name, u.email AS assignee_email, u.avatar_color AS assignee_avatar 
           FROM tasks t 
           LEFT JOIN users u ON t.assignee_id = u.id 
           WHERE t.id = ?`,
          [taskId]
        );
      });

      return success(res, { task: newTask }, 201);
    } catch (err) {
      console.error('Create task error:', err);
      return error(res, 'Failed to create task.', 500);
    }
  });

  return router;
};
