// ============================================================================
// Authentication Routes (/api/auth)
// ============================================================================

const { 
  hashPassword, 
  comparePassword, 
  signToken 
} = require('../utils/crypto');
const { 
  isValidEmail, 
  generateAvatarColor, 
  success, 
  error 
} = require('../utils/helpers');
const { queryOne, execute } = require('../../database/db');
const { requireAuth } = require('../middleware/auth');

module.exports = function authRoutes(router) {
  /**
   * POST /api/auth/register
   * Create a new user account with unique email and hashed password
   */
  router.post('/register', async (req, res) => {
    try {
      const { name, email, password } = req.body || {};

      if (!name || !name.trim()) {
        return error(res, 'Name is required.', 400);
      }
      if (!email || !isValidEmail(email)) {
        return error(res, 'A valid email address is required.', 400);
      }
      if (!password || password.length < 6) {
        return error(res, 'Password must be at least 6 characters long.', 400);
      }

      const trimmedEmail = email.trim().toLowerCase();
      const trimmedName = name.trim();

      // Check if email already registered
      const existing = queryOne('SELECT id FROM users WHERE email = ?', [trimmedEmail]);
      if (existing) {
        return error(res, 'An account with this email address already exists.', 409);
      }

      const passwordHash = await hashPassword(password);
      const avatarColor = generateAvatarColor(trimmedEmail);

      const result = execute(
        'INSERT INTO users (name, email, password_hash, avatar_color) VALUES (?, ?, ?, ?)',
        [trimmedName, trimmedEmail, passwordHash, avatarColor]
      );

      const user = {
        id: result.lastInsertRowid,
        name: trimmedName,
        email: trimmedEmail,
        avatar_color: avatarColor
      };

      const token = signToken({ id: user.id, email: user.email });

      return success(res, {
        message: 'Account registered successfully.',
        token,
        user
      }, 201);
    } catch (err) {
      console.error('Registration error:', err);
      return error(res, 'Registration failed due to a server error.', 500);
    }
  });

  /**
   * POST /api/auth/login
   * Authenticate user credentials and return JWT
   */
  router.post('/login', async (req, res) => {
    try {
      const { email, password } = req.body || {};

      if (!email || !password) {
        return error(res, 'Email and password are required.', 400);
      }

      const trimmedEmail = email.trim().toLowerCase();
      const user = queryOne(
        'SELECT id, name, email, password_hash, avatar_color FROM users WHERE email = ?',
        [trimmedEmail]
      );

      if (!user) {
        return error(res, 'Invalid email or password.', 401);
      }

      const isMatch = await comparePassword(password, user.password_hash);
      if (!isMatch) {
        return error(res, 'Invalid email or password.', 401);
      }

      const token = signToken({ id: user.id, email: user.email });

      return success(res, {
        message: 'Login successful.',
        token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          avatar_color: user.avatar_color
        }
      });
    } catch (err) {
      console.error('Login error:', err);
      return error(res, 'Login failed due to a server error.', 500);
    }
  });

  /**
   * GET /api/auth/me
   * Return authenticated user session info
   */
  router.get('/me', requireAuth, (req, res) => {
    return success(res, { user: req.user });
  });

  return router;
};
