// ============================================================================
// Tasks & Comments Routes (/api/tasks, /api/comments)
// ============================================================================

const { 
  queryAll, 
  queryOne, 
  execute, 
  transaction 
} = require('../../database/db');
const { 
  requireAuth, 
  requireTaskAccess 
} = require('../middleware/auth');
const { 
  sanitizeHtml, 
  success, 
  error 
} = require('../utils/helpers');

module.exports = function taskRoutes(router) {
  /**
   * GET /api/tasks/:id
   * Fetch full task details, including comments and activity audit log
   */
  router.get('/:id', requireAuth, requireTaskAccess('member'), (req, res) => {
    try {
      const taskId = req.task.id;

      // 1. Task with creator and assignee
      const task = queryOne(
        `SELECT 
          t.*, 
          u.name AS assignee_name, 
          u.email AS assignee_email, 
          u.avatar_color AS assignee_avatar,
          creator.name AS creator_name,
          c.name AS column_name
         FROM tasks t 
         JOIN columns c ON t.column_id = c.id
         LEFT JOIN users u ON t.assignee_id = u.id 
         LEFT JOIN users creator ON t.created_by = creator.id
         WHERE t.id = ?`,
        [taskId]
      );

      // Check if overdue
      const today = new Date().toISOString().split('T')[0];
      const maxCol = queryOne(
        'SELECT id FROM columns WHERE board_id = ? ORDER BY position DESC LIMIT 1',
        [task.board_id]
      );
      const isDone = Boolean(maxCol && maxCol.id === task.column_id);
      task.is_overdue = Boolean(task.due_date && task.due_date < today && !isDone);

      // 2. Comments with author info
      const comments = queryAll(
        `SELECT 
          comm.id,
          comm.task_id,
          comm.user_id,
          comm.content,
          comm.created_at,
          u.name AS author_name,
          u.email AS author_email,
          u.avatar_color AS author_avatar
         FROM comments comm
         JOIN users u ON comm.user_id = u.id
         WHERE comm.task_id = ?
         ORDER BY comm.created_at ASC`,
        [taskId]
      );

      // 3. Activity log
      const activities = queryAll(
        `SELECT 
          a.id,
          a.task_id,
          a.user_id,
          a.action,
          a.created_at,
          u.name AS user_name,
          u.avatar_color AS user_avatar
         FROM activity_log a
         JOIN users u ON a.user_id = u.id
         WHERE a.task_id = ?
         ORDER BY a.created_at DESC`,
        [taskId]
      );

      return success(res, { task, comments, activities });
    } catch (err) {
      console.error('Get task error:', err);
      return error(res, 'Failed to fetch task details.', 500);
    }
  });

  /**
   * PUT /api/tasks/:id
   * Update task metadata (title, description, priority, due_date, assignee)
   */
  router.put('/:id', requireAuth, requireTaskAccess('member'), (req, res) => {
    try {
      const { title, description, priority, due_date, assignee_id } = req.body || {};
      const currentTask = req.task;

      if (!title || !title.trim()) {
        return error(res, 'Task title is required.', 400);
      }

      const taskTitle = sanitizeHtml(title.trim());
      const taskDesc = description !== undefined ? sanitizeHtml(description.trim()) : currentTask.description;
      const taskPriority = ['Low', 'Medium', 'High'].includes(priority) ? priority : currentTask.priority;
      const taskDueDate = due_date && /^\d{4}-\d{2}-\d{2}$/.test(due_date) ? due_date : null;

      let validAssigneeId = null;
      if (assignee_id !== undefined && assignee_id !== null && assignee_id !== '') {
        const parsed = parseInt(assignee_id, 10);
        if (!isNaN(parsed)) {
          const member = queryOne(
            'SELECT user_id FROM board_members WHERE board_id = ? AND user_id = ?',
            [req.boardId, parsed]
          );
          if (member) validAssigneeId = parsed;
        }
      }

      transaction((db) => {
        db.execute(
          `UPDATE tasks SET 
            title = ?, 
            description = ?, 
            priority = ?, 
            due_date = ?, 
            assignee_id = ?, 
            updated_at = datetime('now') 
           WHERE id = ?`,
          [taskTitle, taskDesc, taskPriority, taskDueDate, validAssigneeId, currentTask.id]
        );

        // Audit log changes
        if (taskPriority !== currentTask.priority) {
          db.execute(
            'INSERT INTO activity_log (task_id, user_id, action) VALUES (?, ?, ?)',
            [currentTask.id, req.user.id, `Changed priority to "${taskPriority}"`]
          );
        }
        if (validAssigneeId !== currentTask.assignee_id) {
          if (validAssigneeId) {
            const assigneeUser = db.queryOne('SELECT name FROM users WHERE id = ?', [validAssigneeId]);
            db.execute(
              'INSERT INTO activity_log (task_id, user_id, action) VALUES (?, ?, ?)',
              [currentTask.id, req.user.id, `Assigned task to ${assigneeUser ? assigneeUser.name : 'member'}`]
            );
          } else {
            db.execute(
              'INSERT INTO activity_log (task_id, user_id, action) VALUES (?, ?, ?)',
              [currentTask.id, req.user.id, 'Unassigned task']
            );
          }
        }
      });

      const updated = queryOne(
        `SELECT t.*, u.name AS assignee_name, u.email AS assignee_email, u.avatar_color AS assignee_avatar 
         FROM tasks t 
         LEFT JOIN users u ON t.assignee_id = u.id 
         WHERE t.id = ?`,
        [currentTask.id]
      );

      return success(res, { task: updated });
    } catch (err) {
      console.error('Update task error:', err);
      return error(res, 'Failed to update task.', 500);
    }
  });

  /**
   * PATCH /api/tasks/:id/move
   * Safely move task to a new column and/or reorder position
   * Implements integer positions (0..N-1) with atomic transactional renumbering
   */
  router.patch('/:id/move', requireAuth, requireTaskAccess('member'), (req, res) => {
    try {
      const { column_id, position } = req.body || {};
      const currentTask = req.task;
      const boardId = currentTask.board_id;

      if (position === undefined || typeof position !== 'number') {
        return error(res, 'Target position integer is required.', 400);
      }

      const targetColId = column_id !== undefined ? parseInt(column_id, 10) : currentTask.column_id;
      if (isNaN(targetColId)) {
        return error(res, 'Invalid target column ID.', 400);
      }

      // Verify target column belongs to the same board
      const targetColumn = queryOne(
        'SELECT id, name FROM columns WHERE id = ? AND board_id = ?',
        [targetColId, boardId]
      );
      if (!targetColumn) {
        return error(res, 'Target column does not exist on this board.', 400);
      }

      const sourceColId = currentTask.column_id;
      const sourcePos = currentTask.position;

      transaction((db) => {
        if (sourceColId === targetColId) {
          // --- Case 1: Reordering within the SAME column ---
          const countRow = db.queryOne(
            'SELECT COUNT(*) as count FROM tasks WHERE column_id = ?',
            [sourceColId]
          );
          const maxPos = Math.max(0, countRow.count - 1);
          const targetPos = Math.max(0, Math.min(position, maxPos));

          if (sourcePos === targetPos) {
            // No position change needed
            return;
          }

          if (sourcePos < targetPos) {
            // Task moved DOWN: shift items between sourcePos + 1 and targetPos UP (decrease index)
            db.execute(
              `UPDATE tasks 
               SET position = position - 1 
               WHERE column_id = ? AND position > ? AND position <= ?`,
              [sourceColId, sourcePos, targetPos]
            );
          } else {
            // Task moved UP: shift items between targetPos and sourcePos - 1 DOWN (increase index)
            db.execute(
              `UPDATE tasks 
               SET position = position + 1 
               WHERE column_id = ? AND position >= ? AND position < ?`,
              [sourceColId, targetPos, sourcePos]
            );
          }

          // Place task into target position
          db.execute(
            `UPDATE tasks 
             SET position = ?, updated_at = datetime('now') 
             WHERE id = ?`,
            [targetPos, currentTask.id]
          );
        } else {
          // --- Case 2: Moving ACROSS DIFFERENT columns ---
          const sourceCol = db.queryOne('SELECT name FROM columns WHERE id = ?', [sourceColId]);

          // 1. Shift tasks in source column above sourcePos down by 1 to close gap
          db.execute(
            `UPDATE tasks 
             SET position = position - 1 
             WHERE column_id = ? AND position > ?`,
            [sourceColId, sourcePos]
          );

          // 2. Count tasks in target column to clamp target position
          const targetCountRow = db.queryOne(
            'SELECT COUNT(*) as count FROM tasks WHERE column_id = ?',
            [targetColId]
          );
          const targetCount = targetCountRow.count;
          const targetPos = Math.max(0, Math.min(position, targetCount));

          // 3. Shift tasks in target column at or above targetPos up by 1 to make room
          db.execute(
            `UPDATE tasks 
             SET position = position + 1 
             WHERE column_id = ? AND position >= ?`,
            [targetColId, targetPos]
          );

          // 4. Update task with new column and position
          db.execute(
            `UPDATE tasks 
             SET column_id = ?, position = ?, updated_at = datetime('now') 
             WHERE id = ?`,
            [targetColId, targetPos, currentTask.id]
          );

          // 5. Log move activity
          db.execute(
            'INSERT INTO activity_log (task_id, user_id, action) VALUES (?, ?, ?)',
            [
              currentTask.id,
              req.user.id,
              `Moved task from "${sourceCol ? sourceCol.name : 'column'}" to "${targetColumn.name}"`
            ]
          );
        }
      });

      const updated = queryOne(
        `SELECT t.*, u.name AS assignee_name, u.email AS assignee_email, u.avatar_color AS assignee_avatar 
         FROM tasks t 
         LEFT JOIN users u ON t.assignee_id = u.id 
         WHERE t.id = ?`,
        [currentTask.id]
      );

      return success(res, { task: updated });
    } catch (err) {
      console.error('Move task error:', err);
      return error(res, 'Failed to move task.', 500);
    }
  });

  /**
   * DELETE /api/tasks/:id
   * Delete task with confirmation (Member)
   */
  router.delete('/:id', requireAuth, requireTaskAccess('member'), (req, res) => {
    try {
      const currentTask = req.task;

      transaction((db) => {
        // Delete task (foreign keys cascade to comments and activity_log)
        db.execute('DELETE FROM tasks WHERE id = ?', [currentTask.id]);

        // Renumber remaining tasks in the column to maintain contiguous 0..N-1
        db.execute(
          `UPDATE tasks 
           SET position = position - 1 
           WHERE column_id = ? AND position > ?`,
          [currentTask.column_id, currentTask.position]
        );
      });

      return success(res, { message: 'Task deleted successfully.' });
    } catch (err) {
      console.error('Delete task error:', err);
      return error(res, 'Failed to delete task.', 500);
    }
  });

  /**
   * POST /api/tasks/:id/comments
   * Add a new comment to the task
   */
  router.post('/:id/comments', requireAuth, requireTaskAccess('member'), (req, res) => {
    try {
      const { content } = req.body || {};
      if (!content || !content.trim()) {
        return error(res, 'Comment text cannot be empty.', 400);
      }

      const cleanContent = sanitizeHtml(content.trim());

      const newComment = transaction((db) => {
        const insertRes = db.execute(
          'INSERT INTO comments (task_id, user_id, content) VALUES (?, ?, ?)',
          [req.task.id, req.user.id, cleanContent]
        );

        db.execute(
          'INSERT INTO activity_log (task_id, user_id, action) VALUES (?, ?, ?)',
          [req.task.id, req.user.id, 'Commented on task']
        );

        return db.queryOne(
          `SELECT comm.*, u.name AS author_name, u.email AS author_email, u.avatar_color AS author_avatar 
           FROM comments comm 
           JOIN users u ON comm.user_id = u.id 
           WHERE comm.id = ?`,
          [insertRes.lastInsertRowid]
        );
      });

      return success(res, { comment: newComment }, 201);
    } catch (err) {
      console.error('Add comment error:', err);
      return error(res, 'Failed to post comment.', 500);
    }
  });

  return router;
};
