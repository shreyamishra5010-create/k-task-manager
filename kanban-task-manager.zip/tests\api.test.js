// ============================================================================
// Automated In-Memory End-to-End API Test Suite
// Fully isolated and executes directly against SQLite database and Express routes
// without requiring loopback network socket bindings.
// ============================================================================

const path = require('node:path');
const fs = require('node:fs');

// Use isolated test database
const TEST_DB = path.join(__dirname, 'test_kanban.db');
if (fs.existsSync(TEST_DB)) fs.unlinkSync(TEST_DB);
process.env.DB_FILE = TEST_DB;

const { initDb } = require('../database/db');
initDb();

// Load Express app components directly
const authRoutes = require('../src/routes/auth');
const boardRoutes = require('../src/routes/boards');
const columnRoutes = require('../src/routes/columns');
const taskRoutes = require('../src/routes/tasks');
const commentRoutes = require('../src/routes/comments');
const miniExpress = require('../src/utils/mini-express');

// Build isolated application instance for testing
const app = miniExpress();
app.use(miniExpress.json());

const routerAuth = miniExpress.Router();
const routerBoards = miniExpress.Router();
const routerCols = miniExpress.Router();
const routerTasks = miniExpress.Router();
const routerComms = miniExpress.Router();

app.use('/api/auth', authRoutes(routerAuth));
app.use('/api/boards', boardRoutes(routerBoards));
app.use('/api/columns', columnRoutes(routerCols));
app.use('/api/tasks', taskRoutes(routerTasks));
app.use('/api/comments', commentRoutes(routerComms));

/**
 * In-memory Mock HTTP Dispatcher
 */
function testRequest(method, urlString, body = null, token = null) {
  return new Promise((resolve) => {
    const parsedUrl = new URL(urlString, 'http://localhost');
    const pathname = parsedUrl.pathname;
    const query = Object.fromEntries(parsedUrl.searchParams.entries());

    const req = {
      method: method.toUpperCase(),
      url: urlString,
      pathname,
      query,
      params: {},
      headers: {
        'content-type': 'application/json',
        ...(token ? { 'authorization': `Bearer ${token}` } : {})
      },
      body: body || {}
    };

    let statusCode = 200;
    let responseBody = null;
    let isEnded = false;

    const res = {
      statusCode: 200,
      headers: {},
      setHeader(name, val) { this.headers[name] = val; },
      status(code) {
        this.statusCode = code;
        statusCode = code;
        return this;
      },
      json(data) {
        if (isEnded) return;
        isEnded = true;
        responseBody = data;
        resolve({ status: statusCode, body: responseBody });
      },
      send(data) {
        if (isEnded) return;
        isEnded = true;
        responseBody = data;
        resolve({ status: statusCode, body: responseBody });
      },
      end(data) {
        if (isEnded) return;
        isEnded = true;
        resolve({ status: statusCode, body: data });
      }
    };

    // Locate route
    const allRouters = [
      { prefix: '/api/auth', r: routerAuth },
      { prefix: '/api/boards', r: routerBoards },
      { prefix: '/api/columns', r: routerCols },
      { prefix: '/api/tasks', r: routerTasks },
      { prefix: '/api/comments', r: routerComms }
    ];

    let matched = null;
    let params = {};

    for (const { prefix, r } of allRouters) {
      if (pathname.startsWith(prefix)) {
        const subPath = pathname.slice(prefix.length) || '/';
        for (const route of r.routes) {
          if (route.method === req.method) {
            const m = subPath.match(route.regex);
            if (m) {
              matched = route;
              route.keys.forEach((k, idx) => {
                params[k] = decodeURIComponent(m[idx + 1]);
              });
              break;
            }
          }
        }
        if (matched) break;
      }
    }

    if (!matched) {
      return resolve({ status: 404, body: { success: false, error: 'Not Found' } });
    }

    req.params = params;

    // Execute route pipeline
    let step = 0;
    function next(err) {
      if (isEnded) return;
      if (err) {
        return resolve({ status: 500, body: { success: false, error: err.message } });
      }
      if (step < matched.handlers.length) {
        const handler = matched.handlers[step++];
        try {
          const ret = handler(req, res, next);
          if (ret && typeof ret.catch === 'function') ret.catch(next);
        } catch (syncErr) {
          next(syncErr);
        }
      }
    }

    next();
  });
}

let testPassed = 0;
let testFailed = 0;

function assert(condition, message) {
  if (!condition) {
    console.error(`  ✗ FAIL: ${message}`);
    testFailed++;
    throw new Error(message);
  } else {
    console.log(`  ✓ PASS: ${message}`);
    testPassed++;
  }
}

async function runTests() {
  console.log('====================================================');
  console.log(' Running Kanban Automated End-to-End Test Suite    ');
  console.log('====================================================\n');

  try {
    // ----------------------------------------------------
    // 1. Authentication Tests
    // ----------------------------------------------------
    console.log('1. User Registration & JWT Authentication');
    const regRes = await testRequest('POST', '/api/auth/register', {
      name: 'Test Owner',
      email: 'owner@test.com',
      password: 'password123'
    });
    assert(regRes.status === 201, 'Registration returns HTTP 201 Created');
    assert(Boolean(regRes.body.data.token), 'Registration issues signed JWT session token');
    const ownerToken = regRes.body.data.token;
    const ownerUser = regRes.body.data.user;

    // Register second user (Member)
    const memRes = await testRequest('POST', '/api/auth/register', {
      name: 'Test Member',
      email: 'member@test.com',
      password: 'password123'
    });
    assert(memRes.status === 201, 'Second user registered successfully');
    const memberToken = memRes.body.data.token;
    const memberUser = memRes.body.data.user;

    // Register third user (Non-member)
    const outRes = await testRequest('POST', '/api/auth/register', {
      name: 'Test Outsider',
      email: 'outsider@test.com',
      password: 'password123'
    });
    const outsiderToken = outRes.body.data.token;

    // Login with valid credentials
    const loginRes = await testRequest('POST', '/api/auth/login', {
      email: 'owner@test.com',
      password: 'password123'
    });
    assert(loginRes.status === 200, 'Login succeeds with valid password');
    assert(loginRes.body.data.user.email === 'owner@test.com', 'Login returns user profile');

    // Login with invalid credentials
    const badLogin = await testRequest('POST', '/api/auth/login', {
      email: 'owner@test.com',
      password: 'wrong-password'
    });
    assert(badLogin.status === 401, 'Invalid password rejected with HTTP 401');

    // ----------------------------------------------------
    // 2. Board Creation & Default Columns
    // ----------------------------------------------------
    console.log('\n2. Board Creation & Default Columns');
    const bRes = await testRequest('POST', '/api/boards', {
      name: 'Engineering Sprint 1',
      description: 'Core backend development'
    }, ownerToken);
    assert(bRes.status === 201, 'Board created successfully with HTTP 201');
    const boardId = bRes.body.data.board.id;

    // Fetch board details
    const bDetails = await testRequest('GET', `/api/boards/${boardId}`, null, ownerToken);
    assert(bDetails.status === 200, 'Fetch board details returns HTTP 200');
    assert(bDetails.body.data.columns.length === 3, 'Board automatically initialized with 3 default columns (To Do, In Progress, Done)');
    const colTodo = bDetails.body.data.columns[0];
    const colInProgress = bDetails.body.data.columns[1];
    const colDone = bDetails.body.data.columns[2];

    // Add new column
    const colAddRes = await testRequest('POST', `/api/boards/${boardId}/columns`, {
      name: 'Code Review'
    }, ownerToken);
    assert(colAddRes.status === 201, 'New column created with position auto-increment');

    // ----------------------------------------------------
    // 3. Authorization & Member Management
    // ----------------------------------------------------
    console.log('\n3. Role-Based Access Control & Membership');
    // Outsider denied access
    const outsiderAccess = await testRequest('GET', `/api/boards/${boardId}`, null, outsiderToken);
    assert(outsiderAccess.status === 403, 'Non-member access is blocked with HTTP 403 Forbidden');

    // Owner adds member
    const addMemberRes = await testRequest('POST', `/api/boards/${boardId}/members`, {
      email: 'member@test.com'
    }, ownerToken);
    assert(addMemberRes.status === 201, 'Owner can add member by email');

    // Added member now has access
    const memberAccess = await testRequest('GET', `/api/boards/${boardId}`, null, memberToken);
    assert(memberAccess.status === 200, 'Newly added member successfully accesses board');

    // Member cannot delete board (owner only)
    const memDelBoard = await testRequest('DELETE', `/api/boards/${boardId}`, null, memberToken);
    assert(memDelBoard.status === 403, 'Member cannot delete board (HTTP 403)');

    // ----------------------------------------------------
    // 4. Task Creation, Moving & Transactional Renumbering
    // ----------------------------------------------------
    console.log('\n4. Tasks, Position Renumbering & Cross-Column Movement');
    const t1 = await testRequest('POST', `/api/columns/${colTodo.id}/tasks`, {
      title: 'Setup Database Connection',
      description: 'Configure foreign keys and WAL mode',
      priority: 'High',
      assignee_id: memberUser.id
    }, memberToken);
    assert(t1.status === 201, 'Task 1 created in To Do column');
    const task1Id = t1.body.data.task.id;

    const t2 = await testRequest('POST', `/api/columns/${colTodo.id}/tasks`, {
      title: 'Build JWT Middleware',
      priority: 'Medium'
    }, memberToken);
    assert(t2.status === 201, 'Task 2 created in To Do column');
    const task2Id = t2.body.data.task.id;

    // Move Task 1 to In Progress column at position 0
    const moveRes = await testRequest('PATCH', `/api/tasks/${task1Id}/move`, {
      column_id: colInProgress.id,
      position: 0
    }, memberToken);
    assert(moveRes.status === 200, 'Cross-column move returns HTTP 200');
    assert(moveRes.body.data.task.column_id === colInProgress.id, 'Task column_id updated to target column');

    // ----------------------------------------------------
    // 5. Comments & Author-Only Deletion
    // ----------------------------------------------------
    console.log('\n5. Comments & Authorship Permissions');
    const commRes = await testRequest('POST', `/api/tasks/${task1Id}/comments`, {
      content: 'Code is ready for review.'
    }, memberToken);
    assert(commRes.status === 201, 'Member posted comment successfully');
    const commentId = commRes.body.data.comment.id;

    // Owner tries to delete Member's comment -> Should be forbidden
    const ownerDelComm = await testRequest('DELETE', `/api/comments/${commentId}`, null, ownerToken);
    assert(ownerDelComm.status === 403, 'User cannot delete another user\'s comment (HTTP 403)');

    // Author deletes own comment -> Should succeed
    const authorDelComm = await testRequest('DELETE', `/api/comments/${commentId}`, null, memberToken);
    assert(authorDelComm.status === 200, 'Author can delete their own comment (HTTP 200)');

    // ----------------------------------------------------
    // 6. Task Deletion & Cascading Clean-up
    // ----------------------------------------------------
    console.log('\n6. Task Deletion & Renumbering');
    const delTaskRes = await testRequest('DELETE', `/api/tasks/${task2Id}`, null, memberToken);
    assert(delTaskRes.status === 200, 'Task deleted successfully');

    // ----------------------------------------------------
    // 7. Search & Filter Endpoints
    // ----------------------------------------------------
    console.log('\n7. Search & Filter Endpoints');
    const searchRes = await testRequest('GET', `/api/boards/${boardId}/tasks?q=Database`, null, memberToken);
    assert(searchRes.status === 200, 'Task search returns HTTP 200');
    assert(searchRes.body.data.tasks.length === 1, 'Search query correctly matched 1 task');

    console.log('\n====================================================');
    console.log(` ALL TESTS PASSED: ${testPassed} Passed, ${testFailed} Failed `);
    console.log('====================================================\n');
  } catch (err) {
    console.error('Test Suite Failed:', err);
    process.exitCode = 1;
  } finally {
    if (fs.existsSync(TEST_DB)) {
      try { fs.unlinkSync(TEST_DB); } catch (e) {}
    }
  }
}

runTests();
