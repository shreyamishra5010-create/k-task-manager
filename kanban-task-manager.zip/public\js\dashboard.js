// ============================================================================
// Dashboard Page Logic: Boards Management
// ============================================================================

auth.requireAuth();

document.addEventListener('DOMContentLoaded', () => {
  auth.renderNavbar();
  loadBoards();
  setupCreateBoardModal();
});

let allBoards = [];

/**
 * Fetch and display all user boards
 */
async function loadBoards() {
  const grid = document.getElementById('boards-grid');
  if (!grid) return;

  grid.innerHTML = `
    <div style="grid-column: 1/-1; text-align: center; padding: 3rem; color: var(--text-secondary);">
      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="animation: spin 1s linear infinite; margin-bottom: 0.5rem;">
        <circle cx="12" cy="12" r="10" stroke-width="3" stroke-dasharray="32" stroke-dashoffset="12"></circle>
      </svg>
      <p>Loading your boards...</p>
    </div>
  `;

  try {
    const data = await api.get('/api/boards');
    allBoards = data.boards || [];
    renderBoards(allBoards);
  } catch (err) {
    grid.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 2rem; color: var(--danger);">
        <p>Failed to load boards: ${err.message}</p>
        <button class="btn btn-secondary btn-sm" onclick="loadBoards()" style="margin-top: 0.75rem;">Retry</button>
      </div>
    `;
    showToast(err.message, 'error');
  }
}

/**
 * Render board cards
 */
function renderBoards(boards) {
  const grid = document.getElementById('boards-grid');
  if (!grid) return;

  if (boards.length === 0) {
    grid.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 4rem 1.5rem; background: var(--bg-surface); border: 2px dashed var(--border-color); border-radius: var(--radius-lg);">
        <svg width="48" height="48" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color: var(--text-muted); margin-bottom: 1rem;">
          <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
          <line x1="9" y1="3" x2="9" y2="21"></line>
          <line x1="15" y1="3" x2="15" y2="21"></line>
        </svg>
        <h3 style="font-size: 1.2rem; margin-bottom: 0.5rem;">No boards found</h3>
        <p style="color: var(--text-secondary); margin-bottom: 1.5rem;">Create your first board to start tracking sprints, tasks, and ideas.</p>
        <button class="btn btn-primary" onclick="openCreateBoardModal()">
          <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
          Create New Board
        </button>
      </div>
    `;
    return;
  }

  grid.innerHTML = boards.map(board => {
    const isOwner = board.role === 'owner';
    const roleBadge = isOwner
      ? '<span class="badge badge-owner">Owner</span>'
      : '<span class="badge badge-member">Member</span>';

    return `
      <a href="/board.html?id=${board.id}" class="board-card">
        <div>
          <div class="board-card-header">
            <h2 class="board-card-title">${escapeHtml(board.name)}</h2>
            ${roleBadge}
          </div>
          <p class="board-card-desc">${escapeHtml(board.description || 'No description provided.')}</p>
        </div>
        <div class="board-card-footer">
          <div style="display:flex; align-items:center; gap:0.35rem;">
            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path></svg>
            <span><strong>${board.task_count || 0}</strong> tasks</span>
          </div>
          <div style="display:flex; align-items:center; gap:0.35rem;">
            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
            <span><strong>${board.member_count || 1}</strong> members</span>
          </div>
        </div>
      </a>
    `;
  }).join('');
}

/**
 * Board search filter input
 */
const searchInput = document.getElementById('search-boards-input');
if (searchInput) {
  searchInput.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase().trim();
    if (!term) {
      renderBoards(allBoards);
      return;
    }
    const filtered = allBoards.filter(b => 
      b.name.toLowerCase().includes(term) || 
      (b.description && b.description.toLowerCase().includes(term))
    );
    renderBoards(filtered);
  });
}

/**
 * Setup Create Board Modal
 */
function setupCreateBoardModal() {
  const modal = document.getElementById('create-board-modal');
  const openBtn = document.getElementById('open-create-board-btn');
  const cancelBtn = document.getElementById('cancel-create-board-btn');
  const form = document.getElementById('create-board-form');

  if (openBtn) openBtn.addEventListener('click', openCreateBoardModal);
  if (cancelBtn) cancelBtn.addEventListener('click', closeCreateBoardModal);

  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeCreateBoardModal();
    });
  }

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const nameInput = document.getElementById('new-board-name');
      const descInput = document.getElementById('new-board-desc');
      const submitBtn = form.querySelector('button[type="submit"]');

      const name = nameInput.value.trim();
      const description = descInput.value.trim();

      if (!name) {
        showToast('Board name is required', 'error');
        return;
      }

      submitBtn.disabled = true;
      submitBtn.textContent = 'Creating...';

      try {
        const data = await api.post('/api/boards', { name, description });
        showToast('Board created successfully!', 'success');
        closeCreateBoardModal();
        // Redirect to new board
        window.location.href = `/board.html?id=${data.board.id}`;
      } catch (err) {
        showToast(err.message, 'error');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Create Board';
      }
    });
  }
}

function openCreateBoardModal() {
  const modal = document.getElementById('create-board-modal');
  if (modal) {
    modal.classList.add('active');
    setTimeout(() => {
      document.getElementById('new-board-name')?.focus();
    }, 100);
  }
}

function closeCreateBoardModal() {
  const modal = document.getElementById('create-board-modal');
  if (modal) {
    modal.classList.remove('active');
    document.getElementById('create-board-form')?.reset();
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
