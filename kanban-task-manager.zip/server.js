// ============================================================================
// Full-Stack Kanban Task Manager Server
// Node.js + Express.js + SQLite (Foreign Keys & WAL Mode)
// ============================================================================

const path = require('node:path');
const fs = require('node:fs');

// Optional dotenv support
try {
  require('dotenv').config();
} catch (e) {
  // Dotenv is optional; fallback to process.env defaults
}

// Database initialization
const { initDb, seedDb, queryOne } = require('./database/db');
initDb();

// Auto-seed if database is completely empty
const userCount = queryOne('SELECT COUNT(*) as count FROM users');
if (userCount && userCount.count === 0) {
  console.log('Database is empty. Populating with demo seed data...');
  seedDb();
}

// Load Express (with seamless zero-dependency fallback)
let express;
try {
  express = require('express');
} catch (err) {
  express = require('./src/utils/mini-express');
}

// Load CORS
let cors;
try {
  cors = require('cors');
} catch (err) {
  // Built-in CORS middleware fallback
  cors = () => (req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    if (req.method === 'OPTIONS') {
      res.statusCode = 204;
      return res.end();
    }
    next();
  };
}

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Serve static frontend files
const publicDir = path.join(__dirname, 'public');
app.use(express.static(publicDir));

// Route handlers
const authRoutes = require('./src/routes/auth');
const boardRoutes = require('./src/routes/boards');
const columnRoutes = require('./src/routes/columns');
const taskRoutes = require('./src/routes/tasks');
const commentRoutes = require('./src/routes/comments');

app.use('/api/auth', authRoutes(express.Router()));
app.use('/api/boards', boardRoutes(express.Router()));
app.use('/api/columns', columnRoutes(express.Router()));
app.use('/api/tasks', taskRoutes(express.Router()));
app.use('/api/comments', commentRoutes(express.Router()));

// Clean UI Route Aliases
app.get('/', (req, res) => res.sendFile(path.join(publicDir, 'index.html')));
app.get('/login', (req, res) => res.sendFile(path.join(publicDir, 'login.html')));
app.get('/register', (req, res) => res.sendFile(path.join(publicDir, 'register.html')));
app.get('/dashboard', (req, res) => res.sendFile(path.join(publicDir, 'dashboard.html')));
app.get('/board', (req, res) => res.sendFile(path.join(publicDir, 'board.html')));

// API 404 Handler
app.use('/api', (req, res) => {
  res.status(404).json({ success: false, error: `API route not found: ${req.method} ${req.url}` });
});

// Centralized Error Handler
app.use((err, req, res, next) => {
  console.error('Server Uncaught Error:', err);
  if (!res.writableEnded) {
    res.status(500).json({ success: false, error: 'Internal server error.' });
  }
});

// Start listening if run directly
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`====================================================`);
    console.log(`  Kanban Task Manager Server running on port ${PORT}`);
    console.log(`  URL: http://localhost:${PORT}`);
    console.log(`====================================================`);
  });
}

module.exports = app;
