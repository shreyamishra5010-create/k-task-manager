# Visual UI Walkthrough & Screenshots Guide

This document presents a complete visual gallery and walkthrough of **Kanban Flow** across desktop, tablet, and mobile viewports, including detailed modal interactions and light/dark theme representations.

---

## 1. Interactive Kanban Board View

The central workspace where sprint tasks are managed across customizable, ordered workflow columns.

![Kanban Board View](docs/screenshots/01-kanban-board-view.svg)

### Key Features Displayed:
- **Horizontal Columns Canvas**: Smooth horizontal scroll supporting arbitrary numbers of columns.
- **Visual Priority Badges**: High (Red), Medium (Amber), and Low (Green) tags on cards.
- **Overdue Task Alerting**: Tasks past their due date that are not in the final column display a prominent red **Overdue** pill with border highlighting.
- **Assignee Avatars**: User initials with deterministic background colors generated from user email.
- **HTML5 Drag & Drop Target**: Drop indicator line showing insertion spot for atomic integer reordering.
- **Search & Filters Toolbar**: Instant filtering by keyword query, priority level, and assignee.

---

## 2. Task Details, Comments & Activity Modal

Clicking any card opens the multi-tab inspection modal for metadata editing, team comments, and audit logging.

![Task Detail Modal](docs/screenshots/02-task-detail-modal.svg)

### Key Features Displayed:
- **Metadata Editing**: Quick updates to task title, rich description, column/status, priority, due date, and assigned member.
- **Collaborative Comments Thread**: Real-time conversation stream with author initials, author name, and relative timestamps (`1 day ago`, `18h ago`).
- **Author-Only Deletion**: Trash icon visible exclusively on comments authored by the logged-in user.
- **Activity Audit Trail**: History recording task creation, column transfers, priority changes, and reassignments.
- **Delete Task Confirmation**: Accessible button allowing members to delete tasks with confirmation dialog.

---

## 3. Workspaces & Boards Dashboard

The landing dashboard listing all boards the user owns or participates in as a member.

![Dashboard View](docs/screenshots/03-dashboard-view.svg)

### Key Features Displayed:
- **Board Cards Grid**: Displays board title, description, and permission badges (**Owner** vs **Member**).
- **Metric Counters**: Real-time summary of total tasks and active members per board.
- **Fast Search**: Instant filtering of boards by keyword.
- **Create Board Modal**: Quick creation flow with automatic 3-column bootstrapping (**To Do**, **In Progress**, **Done**).

---

## 4. Authentication & 1-Click Demo Logins

Clean, split-card authentication interface supporting password hashing and 1-click test credentials.

![Authentication & Login View](docs/screenshots/04-auth-login.svg)

### Key Features Displayed:
- **Client Validation**: Email format validation and password length checks.
- **1-Click Quick Demo Login**: Buttons pre-configured for **Alex Rivers** (Owner), **Sarah Chen** (Lead), and **Marcus Vance** (Engineer) with password `password123`.
- **JWT Session Generation**: Automatic redirection to dashboard upon token receipt.

---

## 5. Dark Mode Theme

High-contrast dark theme optimized for low-light environments with WCAG AAA compliant color pairings.

![Dark Mode View](docs/screenshots/05-dark-mode-board.svg)

### Key Features Displayed:
- **Deep Slate Palette**: `#0f172a` canvas with `#1e293b` surface cards and glowing accent borders.
- **Persistent LocalStorage**: Theme toggling is saved and restored instantly without page reload.
- **Zero-Flicker Execution**: Inline theme script in document `<head>` prevents light theme flash on load.
