@echo off
setlocal enabledelayedexpansion

echo ========================================================
echo   Kanban Task Manager - GitHub Repository Setup Script
echo ========================================================
echo.

:: Check if git is installed
where git >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Git is not found in your system PATH.
    echo.
    echo To install Git:
    echo   1. Download and install Git from: https://git-scm.com/download/win
    echo   2. Or run in PowerShell as Administrator:
    echo        winget install --id Git.Git -e --source winget
    echo.
    echo After installing Git, re-run this script!
    pause
    exit /b 1
)

echo [1/4] Initializing Git repository...
if not exist .git (
    git init -b main
) else (
    echo Git repository already initialized.
)

:: Ensure user identity is configured locally if not set globally
git config user.name >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo Setting default local git author...
    git config user.name "Developer"
    git config user.email "developer@example.com"
)

echo.
echo [2/4] Creating structured, conventional commits...

:: Commit 1: Database & Schemas
git add database/ .gitignore .env.example
git commit -m "feat(database): initialize SQLite schema with foreign keys, WAL mode, and seed data" 2>nul

:: Commit 2: Backend Architecture & Auth
git add src/ server.js package.json
git commit -m "feat(backend): implement Express REST APIs, JWT authentication, and transactional reordering" 2>nul

:: Commit 3: Interactive Frontend & Themes
git add public/
git commit -m "feat(frontend): build responsive Kanban UI with HTML5 Drag & Drop, modals, and light/dark mode" 2>nul

:: Commit 4: Testing & Documentation
git add tests/ README.md ORDERING_LOGIC.md ER_DIAGRAM.md Kanban_API.postman_collection.json setup-git.bat setup-git.ps1
git commit -m "docs(all): add comprehensive architecture docs, automated test suite, and Postman collection" 2>nul

:: Stage any remaining files
git add .
git commit -m "chore: finalize project release and documentation" 2>nul

echo.
echo [3/4] Git commits successfully created:
git log --oneline -n 5
echo.

echo [4/4] Push to GitHub:
echo.
echo Please create a new empty repository on GitHub (https://github.com/new).
set /p REPO_URL="Enter your GitHub Repository URL (e.g., https://github.com/username/kanban-task-manager.git): "

if "%REPO_URL%"=="" (
    echo.
    echo [INFO] No repository URL provided.
    echo Whenever you are ready, run:
    echo   git remote add origin ^<YOUR_GITHUB_REPO_URL^>
    echo   git push -u origin main
) else (
    git remote remove origin 2>nul
    git remote add origin %REPO_URL%
    git branch -M main
    echo Pushing to GitHub...
    git push -u origin main
    if %ERRORLEVEL% equ 0 (
        echo.
        echo [SUCCESS] Code successfully pushed to GitHub!
    ) else (
        echo.
        echo [NOTICE] Push failed or authentication was required.
        echo Run 'git push -u origin main' in your terminal and complete the GitHub sign-in prompt.
    )
)

echo.
echo Setup complete.
pause
