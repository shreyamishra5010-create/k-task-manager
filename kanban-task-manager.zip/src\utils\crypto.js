// ============================================================================
// Cryptography and JWT Utilities
// Works out-of-the-box with zero external dependencies (Node.js crypto)
// and seamlessly upgrades to bcryptjs & jsonwebtoken if installed.
// ============================================================================

const nodeCrypto = require('node:crypto');

const JWT_SECRET = process.env.JWT_SECRET || 'supersecret_kanban_jwt_key_2026_change_in_production';

// Try loading bcryptjs if available
let bcrypt;
try {
  bcrypt = require('bcryptjs');
} catch (e) {
  bcrypt = null;
}

// Try loading jsonwebtoken if available
let jsonwebtoken;
try {
  jsonwebtoken = require('jsonwebtoken');
} catch (e) {
  jsonwebtoken = null;
}

/**
 * Base64 URL encode
 */
function base64UrlEncode(str) {
  return Buffer.from(str)
    .toString('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}

/**
 * Base64 URL decode
 */
function base64UrlDecode(str) {
  str = str.replace(/-/g, '+').replace(/_/g, '/');
  while (str.length % 4) {
    str += '=';
  }
  return Buffer.from(str, 'base64').toString('utf8');
}

/**
 * Hash a password
 * @param {string} password 
 * @returns {Promise<string>}
 */
async function hashPassword(password) {
  if (bcrypt) {
    return bcrypt.hash(password, 10);
  }
  // Built-in scrypt fallback (cryptographically secure)
  const salt = nodeCrypto.randomBytes(16).toString('hex');
  const derivedKey = nodeCrypto.scryptSync(password, salt, 64);
  return `scrypt$${salt}$${derivedKey.toString('hex')}`;
}

/**
 * Compare password with hash
 * @param {string} password 
 * @param {string} hash 
 * @returns {Promise<boolean>}
 */
async function comparePassword(password, hash) {
  if (!hash || !password) return false;

  // If hash is scrypt format
  if (hash.startsWith('scrypt$')) {
    const parts = hash.split('$');
    if (parts.length !== 3) return false;
    const [, salt, originalKey] = parts;
    const derivedKey = nodeCrypto.scryptSync(password, salt, 64);
    const keyBuf = Buffer.from(originalKey, 'hex');
    if (keyBuf.length !== derivedKey.length) return false;
    return nodeCrypto.timingSafeEqual(keyBuf, derivedKey);
  }

  // If hash is standard bcrypt format ($2a$, $2b$, $2y$)
  if (bcrypt) {
    try {
      return await bcrypt.compare(password, hash);
    } catch (e) {
      return false;
    }
  }

  // If running without bcrypt installed and encountering a seed bcrypt hash,
  // we check against standard demo hash fallback or reject
  return false;
}

/**
 * Sign JWT token
 * @param {object} payload 
 * @param {string|number} expiresInSeconds 
 * @returns {string}
 */
function signToken(payload, expiresIn = '7d') {
  if (jsonwebtoken) {
    return jsonwebtoken.sign(payload, JWT_SECRET, { expiresIn });
  }

  // Built-in HS256 JWT Generator
  const header = { alg: 'HS256', typ: 'JWT' };
  const now = Math.floor(Date.now() / 1000);
  
  let expSeconds = 7 * 24 * 3600;
  if (typeof expiresIn === 'number') {
    expSeconds = expiresIn;
  } else if (typeof expiresIn === 'string') {
    if (expiresIn.endsWith('d')) expSeconds = parseInt(expiresIn) * 86400;
    else if (expiresIn.endsWith('h')) expSeconds = parseInt(expiresIn) * 3600;
    else if (expiresIn.endsWith('m')) expSeconds = parseInt(expiresIn) * 60;
  }

  const fullPayload = {
    ...payload,
    iat: now,
    exp: now + expSeconds
  };

  const encodedHeader = base64UrlEncode(JSON.stringify(header));
  const encodedPayload = base64UrlEncode(JSON.stringify(fullPayload));
  const data = `${encodedHeader}.${encodedPayload}`;

  const signature = nodeCrypto
    .createHmac('sha256', JWT_SECRET)
    .update(data)
    .digest('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');

  return `${data}.${signature}`;
}

/**
 * Verify JWT token
 * @param {string} token 
 * @returns {object|null}
 */
function verifyToken(token) {
  if (!token) return null;

  if (jsonwebtoken) {
    try {
      return jsonwebtoken.verify(token, JWT_SECRET);
    } catch (e) {
      return null;
    }
  }

  // Built-in HS256 JWT Verification
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;

    const [encodedHeader, encodedPayload, signature] = parts;
    const data = `${encodedHeader}.${encodedPayload}`;

    const expectedSignature = nodeCrypto
      .createHmac('sha256', JWT_SECRET)
      .update(data)
      .digest('base64')
      .replace(/=/g, '')
      .replace(/\+/g, '-')
      .replace(/\//g, '_');

    const sigBuf = Buffer.from(signature);
    const expBuf = Buffer.from(expectedSignature);
    if (sigBuf.length !== expBuf.length || !nodeCrypto.timingSafeEqual(sigBuf, expBuf)) {
      return null;
    }

    const payload = JSON.parse(base64UrlDecode(encodedPayload));
    const now = Math.floor(Date.now() / 1000);
    if (payload.exp && payload.exp < now) {
      return null; // Expired
    }

    return payload;
  } catch (err) {
    return null;
  }
}

module.exports = {
  hashPassword,
  comparePassword,
  signToken,
  verifyToken,
  JWT_SECRET
};
