# Database Entity-Relationship (ER) Diagram & Schema Architecture

This document provides the complete structural schema specification, relationship cardinalities, and table dictionary for **Kanban Flow**.

---

## 1. Visual Mermaid ER Diagram

```mermaid
erDiagram
    USERS ||--o{ BOARDS : "owns"
    USERS ||--o{ BOARD_MEMBERS : "participates_as"
    USERS ||--o{ TASKS : "created_by"
    USERS ||--o{ TASKS : "assigned_to"
    USERS ||--o{ COMMENTS : "authored"
    USERS ||--o{ ACTIVITY_LOG : "performed"

    BOARDS ||--o{ BOARD_MEMBERS : "has_members"
    BOARDS ||--o{ COLUMNS : "contains_columns"
    BOARDS ||--o{ TASKS : "contains_tasks"

    COLUMNS ||--o{ TASKS : "holds"

    TASKS ||--o{ COMMENTS : "has_comments"
    TASKS ||--o{ ACTIVITY_LOG : "has_activities"

    USERS {
        INTEGER id PK "AUTOINCREMENT"
        TEXT name "NOT NULL"
        TEXT email "UNIQUE, NOT NULL, NOCASE"
        TEXT password_hash "NOT NULL (bcrypt/scrypt)"
        TEXT avatar_color "DEFAULT '#4f46e5'"
        DATETIME created_at "DEFAULT CURRENT_TIMESTAMP"
    }

    BOARDS {
        INTEGER id PK "AUTOINCREMENT"
        TEXT name "NOT NULL"
        TEXT description "DEFAULT ''"
        INTEGER owner_id FK "REFERENCES users(id) ON DELETE CASCADE"
        DATETIME created_at "DEFAULT CURRENT_TIMESTAMP"
    }

    BOARD_MEMBERS {
        INTEGER id PK "AUTOINCREMENT"
        INTEGER board_id FK "REFERENCES boards(id) ON DELETE CASCADE"
        INTEGER user_id FK "REFERENCES users(id) ON DELETE CASCADE"
        TEXT role "CHECK(role IN ('owner','member'))"
        DATETIME created_at "DEFAULT CURRENT_TIMESTAMP"
    }

    COLUMNS {
        INTEGER id PK "AUTOINCREMENT"
        INTEGER board_id FK "REFERENCES boards(id) ON DELETE CASCADE"
        TEXT name "NOT NULL"
        INTEGER position "DEFAULT 0"
        DATETIME created_at "DEFAULT CURRENT_TIMESTAMP"
    }

    TASKS {
        INTEGER id PK "AUTOINCREMENT"
        INTEGER board_id FK "REFERENCES boards(id) ON DELETE CASCADE"
        INTEGER column_id FK "REFERENCES columns(id) ON DELETE CASCADE"
        TEXT title "NOT NULL"
        TEXT description "DEFAULT ''"
        TEXT priority "CHECK(priority IN ('Low','Medium','High'))"
        DATE due_date "NULLABLE"
        INTEGER assignee_id FK "REFERENCES users(id) ON DELETE SET NULL"
        INTEGER created_by FK "REFERENCES users(id) ON DELETE CASCADE"
        INTEGER position "DEFAULT 0"
        DATETIME created_at "DEFAULT CURRENT_TIMESTAMP"
        DATETIME updated_at "DEFAULT CURRENT_TIMESTAMP"
    }

    COMMENTS {
        INTEGER id PK "AUTOINCREMENT"
        INTEGER task_id FK "REFERENCES tasks(id) ON DELETE CASCADE"
        INTEGER user_id FK "REFERENCES users(id) ON DELETE CASCADE"
        TEXT content "NOT NULL"
        DATETIME created_at "DEFAULT CURRENT_TIMESTAMP"
    }

    ACTIVITY_LOG {
        INTEGER id PK "AUTOINCREMENT"
        INTEGER task_id FK "REFERENCES tasks(id) ON DELETE CASCADE"
        INTEGER user_id FK "REFERENCES users(id) ON DELETE CASCADE"
        TEXT action "NOT NULL"
        DATETIME created_at "DEFAULT CURRENT_TIMESTAMP"
    }
```

---

## 2. Table Specifications & Data Dictionary

### Table: `users`
Represents registered users in the system.
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | INTEGER | PRIMARY KEY, AUTOINCREMENT | Unique user identifier. |
| `name` | TEXT | NOT NULL | User's full display name. |
| `email` | TEXT | NOT NULL, UNIQUE, COLLATE NOCASE | Unique login email address. |
| `password_hash` | TEXT | NOT NULL | Hashed password string (bcrypt or scrypt format). |
| `avatar_color` | TEXT | DEFAULT '#4f46e5' | Deterministic hex color for avatar circles. |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | Account registration timestamp. |

---

### Table: `boards`
Represents a Kanban project board containing columns and tasks.
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | INTEGER | PRIMARY KEY, AUTOINCREMENT | Unique board identifier. |
| `name` | TEXT | NOT NULL | Board display title. |
| `description` | TEXT | DEFAULT '' | Optional description or roadmap overview. |
| `owner_id` | INTEGER | NOT NULL, FK `users(id)` ON DELETE CASCADE | User who owns and administers the board. |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | Timestamp when the board was created. |

---

### Table: `board_members`
Association table managing member permissions and access control.
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | INTEGER | PRIMARY KEY, AUTOINCREMENT | Unique membership row identifier. |
| `board_id` | INTEGER | NOT NULL, FK `boards(id)` ON DELETE CASCADE | Associated board. |
| `user_id` | INTEGER | NOT NULL, FK `users(id)` ON DELETE CASCADE | Associated user. |
| `role` | TEXT | NOT NULL, CHECK(`role` IN ('owner', 'member')) | Role tier: 'owner' has full control; 'member' has editing rights. |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | Timestamp when member was added. |
| *Composite* | UNIQUE | `UNIQUE(board_id, user_id)` | Prevents duplicate user memberships per board. |

---

### Table: `columns`
Ordered vertical lists (e.g. To Do, In Progress, Done) belonging to a board.
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | INTEGER | PRIMARY KEY, AUTOINCREMENT | Unique column identifier. |
| `board_id` | INTEGER | NOT NULL, FK `boards(id)` ON DELETE CASCADE | Parent board ID. |
| `name` | TEXT | NOT NULL | Column name (e.g., 'In Progress'). |
| `position` | INTEGER | NOT NULL, DEFAULT 0 | 0-based horizontal ordering position. |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | Timestamp column was added. |

---

### Table: `tasks`
Individual task items tracked on the board.
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | INTEGER | PRIMARY KEY, AUTOINCREMENT | Unique task identifier. |
| `board_id` | INTEGER | NOT NULL, FK `boards(id)` ON DELETE CASCADE | Board this task belongs to. |
| `column_id` | INTEGER | NOT NULL, FK `columns(id)` ON DELETE CASCADE | Current column holding the task. |
| `title` | TEXT | NOT NULL | Required task title. |
| `description` | TEXT | DEFAULT '' | Optional markdown/plain text details. |
| `priority` | TEXT | CHECK(`priority` IN ('Low', 'Medium', 'High')) | Visual priority level. Default: 'Medium'. |
| `due_date` | DATE | NULLABLE | Format: YYYY-MM-DD. Used for overdue alerts. |
| `assignee_id` | INTEGER | NULLABLE, FK `users(id)` ON DELETE SET NULL | User assigned to complete this task. |
| `created_by` | INTEGER | NOT NULL, FK `users(id)` ON DELETE CASCADE | Creator of the task. |
| `position` | INTEGER | NOT NULL, DEFAULT 0 | 0-based vertical position within column. |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | Task creation timestamp. |
| `updated_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | Last modification timestamp. |

---

### Table: `comments`
Collaboration notes posted on specific tasks.
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | INTEGER | PRIMARY KEY, AUTOINCREMENT | Unique comment identifier. |
| `task_id` | INTEGER | NOT NULL, FK `tasks(id)` ON DELETE CASCADE | Parent task. |
| `user_id` | INTEGER | NOT NULL, FK `users(id)` ON DELETE CASCADE | Author of the comment. |
| `content` | TEXT | NOT NULL | Comment text content. |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | Timestamp when comment was posted. |

---

### Table: `activity_log`
Audit history recording actions (moves, priority changes, reassignments).
| Column | Type | Constraints | Description |
| :--- | :--- | :--- | :--- |
| `id` | INTEGER | PRIMARY KEY, AUTOINCREMENT | Unique log entry identifier. |
| `task_id` | INTEGER | NOT NULL, FK `tasks(id)` ON DELETE CASCADE | Associated task. |
| `user_id` | INTEGER | NOT NULL, FK `users(id)` ON DELETE CASCADE | User who initiated the action. |
| `action` | TEXT | NOT NULL | Human-readable audit string. |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | Action occurrence timestamp. |

---

## 3. SQLite Integrity & Performance Indexing

1. **Foreign Key Enforcement**: SQLite connections execute `PRAGMA foreign_keys = ON;` immediately on opening. Deleting a board or column automatically cascades and purges orphaned tasks and comments.
2. **High-Performance Composite Indexes**:
   - `idx_columns_board_pos`: `columns(board_id, position)` — guarantees instant horizontal column sorting.
   - `idx_tasks_col_pos`: `tasks(column_id, position)` — enables sub-millisecond task lookups and range shifts during drag & drop.
   - `idx_board_members_lookup`: `board_members(board_id, user_id)` — validates RBAC permissions in $O(1)$ time.
   - `idx_tasks_assignee`: `tasks(assignee_id)` — accelerates "My Tasks" filters.
