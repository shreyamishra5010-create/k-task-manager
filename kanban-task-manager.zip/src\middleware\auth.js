// ============================================================================
// Authentication & Board Authorization Middleware
// ============================================================================

const { verifyToken } = require('../utils/crypto');
const { queryOne } = require('../../database/db');
const { error } = require('../utils/helpers');

/**
 * Require valid JWT authentication token
 */
function requireAuth(req, res, next) {
  const authHeader = req.headers['authorization'] || req.headers['Authorization'];
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return error(res, 'Authentication required. Please log in.', 401);
  }

  const token = authHeader.slice(7).trim();
  const decoded = verifyToken(token);

  if (!decoded || !decoded.id) {
    return error(res, 'Invalid or expired session token. Please log in again.', 401);
  }

  const user = queryOne('SELECT id, name, email, avatar_color FROM users WHERE id = ?', [decoded.id]);
  if (!user) {
    return error(res, 'User account not found.', 401);
  }

  req.user = user;
  next();
}

/**
 * Check if the user is an owner or member of the board
 * @param {'member'|'owner'} requiredRole 
 */
function requireBoardAccess(requiredRole = 'member') {
  return (req, res, next) => {
    const boardId = req.params.boardId || req.params.id || req.body.board_id;
    if (!boardId) {
      return error(res, 'Board ID parameter is required.', 400);
    }

    const board = queryOne('SELECT * FROM boards WHERE id = ?', [boardId]);
    if (!board) {
      return error(res, 'Board not found.', 404);
    }

    const member = queryOne(
      'SELECT role FROM board_members WHERE board_id = ? AND user_id = ?',
      [boardId, req.user.id]
    );

    if (!member) {
      return error(res, 'Access denied. You are not a member of this board.', 403);
    }

    if (requiredRole === 'owner' && member.role !== 'owner') {
      return error(res, 'Permission denied. Only the board owner can perform this action.', 403);
    }

    req.board = board;
    req.boardRole = member.role;
    next();
  };
}

/**
 * Resolves column and checks board permissions
 * @param {'member'|'owner'} requiredRole 
 */
function requireColumnAccess(requiredRole = 'member') {
  return (req, res, next) => {
    const columnId = req.params.columnId || req.params.id;
    if (!columnId) {
      return error(res, 'Column ID parameter is required.', 400);
    }

    const column = queryOne(
      `SELECT c.*, b.owner_id as board_owner_id 
       FROM columns c 
       JOIN boards b ON c.board_id = b.id 
       WHERE c.id = ?`,
      [columnId]
    );

    if (!column) {
      return error(res, 'Column not found.', 404);
    }

    const member = queryOne(
      'SELECT role FROM board_members WHERE board_id = ? AND user_id = ?',
      [column.board_id, req.user.id]
    );

    if (!member) {
      return error(res, 'Access denied. You are not a member of this board.', 403);
    }

    if (requiredRole === 'owner' && member.role !== 'owner') {
      return error(res, 'Permission denied. Only the board owner can perform this action.', 403);
    }

    req.column = column;
    req.boardId = column.board_id;
    req.boardRole = member.role;
    next();
  };
}

/**
 * Resolves task and checks board permissions
 * @param {'member'|'owner'} requiredRole 
 */
function requireTaskAccess(requiredRole = 'member') {
  return (req, res, next) => {
    const taskId = req.params.taskId || req.params.id;
    if (!taskId) {
      return error(res, 'Task ID parameter is required.', 400);
    }

    const task = queryOne(
      `SELECT t.*, b.owner_id as board_owner_id 
       FROM tasks t 
       JOIN boards b ON t.board_id = b.id 
       WHERE t.id = ?`,
      [taskId]
    );

    if (!task) {
      return error(res, 'Task not found.', 404);
    }

    const member = queryOne(
      'SELECT role FROM board_members WHERE board_id = ? AND user_id = ?',
      [task.board_id, req.user.id]
    );

    if (!member) {
      return error(res, 'Access denied. You are not a member of this board.', 403);
    }

    if (requiredRole === 'owner' && member.role !== 'owner') {
      return error(res, 'Permission denied. Only the board owner can perform this action.', 403);
    }

    req.task = task;
    req.boardId = task.board_id;
    req.boardRole = member.role;
    next();
  };
}

module.exports = {
  requireAuth,
  requireBoardAccess,
  requireColumnAccess,
  requireTaskAccess
};
