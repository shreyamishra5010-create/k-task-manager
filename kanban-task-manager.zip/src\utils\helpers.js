// ============================================================================
// Helper Utilities: Sanitization, Validation, and Response Formatting
// ============================================================================

/**
 * Basic HTML escaping for XSS prevention
 */
function sanitizeHtml(str) {
  if (typeof str !== 'string') return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Validate email format
 */
function isValidEmail(email) {
  if (typeof email !== 'string') return false;
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email.trim());
}

/**
 * Generate a consistent avatar hex color from a string
 */
function generateAvatarColor(str) {
  const colors = [
    '#4f46e5', '#7c3aed', '#2563eb', '#0284c7', 
    '#059669', '#16a34a', '#d97706', '#ea580c', 
    '#dc2626', '#e11d48', '#db2777', '#9333ea'
  ];
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  const index = Math.abs(hash) % colors.length;
  return colors[index];
}

/**
 * Extract 1 or 2 letter initials from a name
 */
function getInitials(name) {
  if (!name) return '?';
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

/**
 * Success JSON response
 */
function success(res, data, statusCode = 200) {
  res.status(statusCode).json({
    success: true,
    data
  });
}

/**
 * Error JSON response
 */
function error(res, message, statusCode = 400, details = null) {
  const payload = {
    success: false,
    error: message
  };
  if (details) payload.details = details;
  res.status(statusCode).json(payload);
}

module.exports = {
  sanitizeHtml,
  isValidEmail,
  generateAvatarColor,
  getInitials,
  success,
  error
};
