// ============================================================================
// SQLite Database Layer with Foreign Keys & Transaction Support
// Works seamlessly with Node.js built-in `node:sqlite` (Node 22+)
// or with `better-sqlite3` when installed.
// ============================================================================

const fs = require('node:fs');
const path = require('node:path');

const DB_PATH = process.env.DB_FILE || path.join(__dirname, 'kanban.db');

let rawDb = null;
let dbDriver = null;

function getDb() {
  if (rawDb) return rawDb;

  // Ensure database directory exists
  const dir = path.dirname(DB_PATH);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  // Attempt 1: Try better-sqlite3
  try {
    const BetterSqlite = require('better-sqlite3');
    rawDb = new BetterSqlite(DB_PATH);
    rawDb.pragma('foreign_keys = ON');
    rawDb.pragma('journal_mode = WAL');
    dbDriver = 'better-sqlite3';
  } catch (err) {
    // Attempt 2: Node.js built-in node:sqlite
    try {
      const { DatabaseSync } = require('node:sqlite');
      rawDb = new DatabaseSync(DB_PATH);
      rawDb.exec('PRAGMA foreign_keys = ON;');
      rawDb.exec('PRAGMA journal_mode = WAL;');
      dbDriver = 'node:sqlite';
    } catch (e2) {
      throw new Error(`Failed to initialize SQLite driver. Error: ${e2.message}`);
    }
  }

  return rawDb;
}

/**
 * Execute a SQL query returning all matching rows
 * @param {string} sql 
 * @param {Array} params 
 * @returns {Array<object>}
 */
function queryAll(sql, params = []) {
  const db = getDb();
  const stmt = db.prepare(sql);
  const rows = stmt.all(...params);
  // Ensure plain JS objects
  return rows.map(r => ({ ...r }));
}

/**
 * Execute a SQL query returning a single row
 * @param {string} sql 
 * @param {Array} params 
 * @returns {object|null}
 */
function queryOne(sql, params = []) {
  const db = getDb();
  const stmt = db.prepare(sql);
  const row = stmt.get(...params);
  return row ? { ...row } : null;
}

/**
 * Execute an INSERT, UPDATE, or DELETE query
 * @param {string} sql 
 * @param {Array} params 
 * @returns {{ lastInsertRowid: number|bigint, changes: number }}
 */
function execute(sql, params = []) {
  const db = getDb();
  const stmt = db.prepare(sql);
  const result = stmt.run(...params);
  return {
    lastInsertRowid: Number(result.lastInsertRowid || 0),
    changes: Number(result.changes || 0)
  };
}

/**
 * Run a multi-statement SQL script (e.g., schema.sql)
 * @param {string} sqlScript 
 */
function execScript(sqlScript) {
  const db = getDb();
  db.exec(sqlScript);
}

/**
 * Run operations inside an atomic transaction
 * @param {Function} callback function that receives db helper
 */
function transaction(callback) {
  const db = getDb();
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = callback({ queryAll, queryOne, execute });
    db.exec('COMMIT');
    return result;
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}

/**
 * Initialize database schema if not already initialized
 */
function initDb() {
  const db = getDb();
  const check = queryOne("SELECT name FROM sqlite_master WHERE type='table' AND name='users'");
  if (!check) {
    const schemaPath = path.join(__dirname, 'schema.sql');
    if (fs.existsSync(schemaPath)) {
      const schemaSql = fs.readFileSync(schemaPath, 'utf8');
      execScript(schemaSql);
      console.log('✓ SQLite schema initialized with foreign keys enabled.');
    }
  }
}

/**
 * Seed database with demo data
 */
function seedDb() {
  initDb();
  const seedPath = path.join(__dirname, 'seed.sql');
  if (fs.existsSync(seedPath)) {
    const seedSql = fs.readFileSync(seedPath, 'utf8');
    execScript(seedSql);
    console.log('✓ Database seeded with initial users, boards, tasks, and comments.');
  }
}

module.exports = {
  getDb,
  queryAll,
  queryOne,
  execute,
  execScript,
  transaction,
  initDb,
  seedDb,
  DB_PATH
};
